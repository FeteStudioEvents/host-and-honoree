import { createRouter } from './core/router.js';
import { store } from './core/store.js';
import { registerServiceWorker } from './core/sw-register.js';
import { toast } from './core/toast.js';
import * as ambient from './features/ambient.js';
import { applyTheme, toggleTheme } from './features/theme.js';

// Views load lazily so first paint only pays for the screen being shown.
const routes = {
  '/': () => import('./views/home.js'),
  '/play': () => import('./views/play.js'),
  '/letter/:id': () => import('./views/letter.js'),
  '/archive': () => import('./views/archive.js'),
};

const router = createRouter({
  root: document.getElementById('view'),
  routes,
  notFound: () => import('./views/not-found.js'),
});

applyTheme();
wireAppBar();
router.start();
registerServiceWorker();

/** App-bar and footer controls that work on every screen. */
function wireAppBar() {
  const themeBtn = document.querySelector('[data-global="theme"]');
  const soundBtn = document.querySelector('[data-global="sound"]');
  const about = document.getElementById('about');
  const eraseBtn = document.querySelector('[data-global="erase"]');

  const syncTheme = () => {
    const light = document.documentElement.dataset.theme === 'light';
    themeBtn.setAttribute('aria-label', light ? 'Switch to night theme' : 'Switch to light theme');
  };
  syncTheme();
  themeBtn.addEventListener('click', () => {
    toggleTheme();
    syncTheme();
  });

  // The sound button appears whenever a soundscape is playing, so it can be paused from anywhere.
  let lastSound = null;
  ambient.onChange((playing) => {
    const id = [...playing][0] ?? null;
    if (id) lastSound = id;
    soundBtn.hidden = !lastSound;
    soundBtn.setAttribute('aria-pressed', String(Boolean(id)));
    soundBtn.setAttribute('aria-label', id ? 'Pause the soundscape' : 'Play the soundscape');
  });
  soundBtn.addEventListener('click', () => {
    const playing = ambient.SOUND_LIST.map((s) => s.id).filter(ambient.isPlaying);
    if (playing.length) playing.forEach(ambient.stop);
    else if (lastSound) ambient.play(lastSound);
  });

  document.querySelectorAll('[data-global="about"]').forEach((btn) => btn.addEventListener('click', () => {
    if (!about.open) about.showModal();
  }));
  document.querySelector('[data-global="close-about"]').addEventListener('click', () => about.close());
  about.addEventListener('click', (e) => {
    if (e.target === about) about.close(); // tap on the backdrop
  });

  // Two-step erase: the first tap arms it, the second (within 5 s) clears this device.
  let armed = null;
  eraseBtn.addEventListener('click', () => {
    if (!armed) {
      eraseBtn.textContent = 'Tap again to erase';
      armed = setTimeout(() => {
        armed = null;
        eraseBtn.textContent = 'Erase everything';
      }, 5000);
      return;
    }
    clearTimeout(armed);
    armed = null;
    eraseBtn.textContent = 'Erase everything';
    ambient.SOUND_LIST.forEach((s) => ambient.stop(s.id));
    store.reset();
    applyTheme();
    syncTheme();
    about.close();
    if (location.hash && location.hash !== '#/') router.navigate('/');
    else window.dispatchEvent(new HashChangeEvent('hashchange'));
    toast('Everything has been erased from this device.');
  });
}
