/**
 * "My year, my new year" share card, drawn on a 1080×1920 canvas (story size).
 *
 * Privacy by construction: the card is drawn from an archive entry, which holds
 * only the year label, word, intentions and highlights. Letters, card answers
 * and the Clear the slate round are never passed in, so they can never be drawn.
 *
 * Every string drawn is recorded in `window.__feteShareText` so the automated
 * tests can prove exactly what the card contains.
 */

export const CARD_W = 1080;
export const CARD_H = 1920;

const SERIF = '"Iowan Old Style", "Palatino Linotype", Palatino, "Book Antiqua", Georgia, "DejaVu Serif", serif';
const SANS = 'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
const GOLD = '#d9bd8c';
const INK = '#f6efe4';
const MUTED = '#c3bcc6';
const BLUSH = '#ebbcc4';

/** Only these fields are ever read. */
export function cardData(entry) {
  return {
    yearLabel: entry.yearLabel ?? '',
    word: entry.word ?? '',
    intentions: (entry.intentions ?? []).filter((i) => i.text).slice(0, 3).map(({ label, text }) => ({ label, text })),
    highlights: (entry.highlights ?? []).slice(0, 3).map(({ month, text }) => ({ month, text })),
  };
}

export async function drawShareCard(entry, canvas = document.createElement('canvas')) {
  const data = cardData(entry);
  canvas.width = CARD_W;
  canvas.height = CARD_H;
  const ctx = canvas.getContext('2d');
  const log = [];
  try { await document.fonts?.ready; } catch { /* fonts are a nicety */ }

  const text = (str, x, y, { font, color = INK, align = 'center', spacing = 0 }) => {
    ctx.font = font;
    ctx.fillStyle = color;
    ctx.textAlign = align;
    ctx.textBaseline = 'alphabetic';
    if ('letterSpacing' in ctx) ctx.letterSpacing = `${spacing}px`;
    ctx.fillText(str, x, y);
    if ('letterSpacing' in ctx) ctx.letterSpacing = '0px';
    log.push(str);
  };

  background(ctx);
  burst(ctx, CARD_W / 2, 232);

  // Lay out once without drawing to find a spacing that fits, then draw for real.
  const LIMIT = CARD_H - 210;
  const tries = [];
  for (const lines of [2, 1]) for (let g = 1; g >= 0.6; g -= 0.04) tries.push({ lines, g });
  let opts = tries[tries.length - 1];
  for (const t of tries) {
    if (compose(ctx, data, t, null) <= LIMIT) { opts = t; break; }
  }
  compose(ctx, data, opts, text);

  // The shop mark, small and quiet.
  smallBurst(ctx, CARD_W / 2, CARD_H - 168);
  text('Fête Studio Events', CARD_W / 2, CARD_H - 104, { font: `500 26px ${SANS}`, color: GOLD, spacing: 5 });

  window.__feteShareText = log;
  return { canvas, log };
}

/** Positions every line of the card; draws only when `draw` is given. Returns the final y. */
function compose(ctx, data, { lines, g }, draw) {
  const put = (str, x, y, style) => {
    if (draw) draw(str, x, y, style);
  };
  const cx = CARD_W / 2;
  let y = 486;
  put('MY YEAR, MY NEW YEAR', cx, y, { font: `600 30px ${SANS}`, color: GOLD, spacing: 9 });
  y += 70;
  put(data.yearLabel, cx, y, { font: `500 50px ${SERIF}`, color: INK });
  y += 74 * g;
  if (draw) rule(ctx, y);
  y += 80 * g;

  if (data.word) {
    put('WORD OF THE YEAR', cx, y, { font: `600 26px ${SANS}`, color: MUTED, spacing: 8 });
    const size = fitSize(ctx, data.word, `italic 500 {s}px ${SERIF}`, 880, 144, 64);
    y += Math.round(size * 0.98);
    put(data.word, cx, y, { font: `italic 500 ${size}px ${SERIF}`, color: GOLD });
    y += 70 + 26 * g; // room for descenders, whatever the spacing
  }

  if (data.intentions.length) {
    put('THREE INTENTIONS', cx, y, { font: `600 26px ${SANS}`, color: MUTED, spacing: 8 });
    y += 62 * g;
    for (const { label, text: body } of data.intentions) {
      put(label.toUpperCase(), cx, y, { font: `600 24px ${SANS}`, color: BLUSH, spacing: 6 });
      y += 52;
      for (const line of wrap(ctx, body, `500 40px ${SERIF}`, 860, lines)) {
        put(line, cx, y, { font: `500 40px ${SERIF}`, color: INK });
        y += 52;
      }
      y += 22 * g;
    }
  }

  if (data.highlights.length) {
    y += 8 * g;
    if (draw) rule(ctx, y);
    y += 74 * g;
    put('HIGHLIGHTS', cx, y, { font: `600 26px ${SANS}`, color: MUTED, spacing: 8 });
    y += 62 * g;
    for (const { month, text: body } of data.highlights) {
      const line = wrap(ctx, body, `italic 400 38px ${SERIF}`, 820, 1)[0] ?? '';
      put(month.toUpperCase(), cx, y, { font: `600 22px ${SANS}`, color: GOLD, spacing: 6 });
      y += 50;
      put(line, cx, y, { font: `italic 400 38px ${SERIF}`, color: INK });
      y += 64 * g;
    }
  }
  return y;
}

export async function shareCardBlob(entry) {
  const { canvas } = await drawShareCard(entry);
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error('Could not create the image'))), 'image/png');
  });
}

export const fileName = (entry) => `my-new-year-${entry.newYear ?? 'card'}.png`;

/** True when this browser can hand a PNG to the system share sheet. */
export function canShareFiles() {
  try {
    const probe = new File([new Blob()], 'card.png', { type: 'image/png' });
    return Boolean(navigator.canShare?.({ files: [probe] }));
  } catch {
    return false;
  }
}

/** Opens the share sheet where supported, otherwise downloads the PNG. Returns what happened. */
export async function exportShareCard(entry) {
  const blob = await shareCardBlob(entry);
  const file = new File([blob], fileName(entry), { type: 'image/png' });
  if (canShareFiles()) {
    try {
      await navigator.share({ files: [file], title: 'My year, my new year' });
      return 'shared';
    } catch (err) {
      if (err?.name === 'AbortError') return 'cancelled';
      // Some browsers refuse a share they said they supported: fall through to a download.
    }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = file.name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
  return 'downloaded';
}

// ─── Drawing helpers ─────────────────────────────────────────────────────────

function background(ctx) {
  const g = ctx.createLinearGradient(0, 0, 0, CARD_H);
  g.addColorStop(0, '#0f0e17');
  g.addColorStop(0.55, '#1c1a2a');
  g.addColorStop(1, '#2b2440');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, CARD_W, CARD_H);

  const glow = ctx.createRadialGradient(CARD_W / 2, 232, 20, CARD_W / 2, 232, 520);
  glow.addColorStop(0, 'rgba(217, 189, 140, 0.22)');
  glow.addColorStop(1, 'rgba(217, 189, 140, 0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, CARD_W, 900);

  // A fixed scatter of tiny stars, so every card looks the same.
  const stars = [[96, 140, 3], [212, 420, 2], [880, 132, 3], [980, 380, 2], [140, 760, 2], [960, 820, 3],
    [70, 1180, 2], [1010, 1240, 2], [180, 1560, 3], [900, 1620, 2], [520, 96, 2], [760, 520, 2], [300, 210, 2]];
  for (const [x, y, r] of stars) {
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(246, 239, 228, 0.55)';
    ctx.fill();
  }
}

function burst(ctx, cx, cy) {
  ctx.save();
  ctx.strokeStyle = GOLD;
  ctx.lineCap = 'round';
  for (let i = 0; i < 24; i++) {
    const a = (i / 24) * Math.PI * 2 - Math.PI / 2;
    const r1 = 132;
    const r2 = i % 2 ? 170 : 204;
    ctx.globalAlpha = i % 2 ? 0.55 : 0.9;
    ctx.lineWidth = i % 2 ? 6 : 8;
    ctx.beginPath();
    ctx.moveTo(cx + r1 * Math.cos(a), cy + r1 * Math.sin(a));
    ctx.lineTo(cx + r2 * Math.cos(a), cy + r2 * Math.sin(a));
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.arc(cx, cy, 98, 0, Math.PI * 2);
  ctx.stroke();
  ctx.strokeStyle = INK;
  ctx.lineWidth = 14;
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.lineTo(cx, cy - 58);
  ctx.stroke();
  ctx.fillStyle = BLUSH;
  ctx.beginPath();
  ctx.arc(cx, cy - 76, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = GOLD;
  ctx.beginPath();
  ctx.arc(cx, cy, 12, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function smallBurst(ctx, cx, cy) {
  ctx.save();
  ctx.strokeStyle = GOLD;
  ctx.globalAlpha = 0.8;
  ctx.lineWidth = 3;
  ctx.lineCap = 'round';
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(cx + 10 * Math.cos(a), cy + 10 * Math.sin(a));
    ctx.lineTo(cx + (i % 2 ? 18 : 24) * Math.cos(a), cy + (i % 2 ? 18 : 24) * Math.sin(a));
    ctx.stroke();
  }
  ctx.restore();
}

function rule(ctx, y) {
  ctx.save();
  ctx.strokeStyle = 'rgba(217, 189, 140, 0.45)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(CARD_W / 2 - 120, y);
  ctx.lineTo(CARD_W / 2 + 120, y);
  ctx.stroke();
  ctx.restore();
}

/** Largest font size (in steps of 4px) at which `str` fits `maxWidth`. */
function fitSize(ctx, str, template, maxWidth, max, min) {
  for (let s = max; s > min; s -= 4) {
    ctx.font = template.replace('{s}', s);
    if (ctx.measureText(str).width <= maxWidth) return s;
  }
  return min;
}

/** Word-wraps to at most `maxLines`, ending with an ellipsis if text is cut. */
function wrap(ctx, str, font, maxWidth, maxLines) {
  ctx.font = font;
  const words = String(str).trim().split(/\s+/).filter(Boolean);
  const lines = [];
  let line = '';
  for (let i = 0; i < words.length; i++) {
    const next = line ? `${line} ${words[i]}` : words[i];
    if (ctx.measureText(next).width <= maxWidth || !line) {
      line = next;
    } else {
      lines.push(line);
      line = words[i];
      if (lines.length === maxLines) {
        line = '';
        lines[maxLines - 1] = ellipsize(ctx, `${lines[maxLines - 1]} ${words.slice(i).join(' ')}`, maxWidth);
        break;
      }
    }
  }
  if (line) lines.push(line);
  return lines.slice(0, maxLines).map((l) => ellipsize(ctx, l, maxWidth));
}

function ellipsize(ctx, str, maxWidth) {
  if (ctx.measureText(str).width <= maxWidth) return str;
  let s = str;
  while (s.length > 1 && ctx.measureText(`${s}…`).width > maxWidth) s = s.slice(0, -1);
  return `${s.trimEnd()}…`;
}
