/**
 * Ambient sound engine. Every sound is synthesized with the Web Audio API
 * from generated noise buffers, so there are no audio files to download or cache.
 *
 * Graph: voice sources → filters → voice gain (fade in/out) → master gain → speakers
 */

const SOUNDS = {
  brown: { label: 'Brown noise', note: 'A deep, steady hush', build: buildBrown },
  rain: { label: 'Rain', note: 'Soft rain on glass', build: buildRain },
  cabin: { label: 'Forest cabin', note: 'Hearth and pine wind', build: buildCabin },
  snow: { label: 'Soft snow', note: 'Hushed wind, soft drift', build: buildSnow },
};

export const SOUND_LIST = Object.entries(SOUNDS).map(([id, { label, note }]) => ({ id, label, note }));

let ctx = null;
let master = null;
let volume = 0.7;
let fadeTimer = null;
const voices = new Map();
const buffers = {};
const listeners = new Set();

/** Subscribe to the set of playing sound ids. Returns an unsubscribe function. */
export function onChange(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

const emit = () => listeners.forEach((fn) => fn(new Set(voices.keys())));

export const isPlaying = (id) => voices.has(id);

export function toggle(id) {
  if (voices.has(id)) stop(id);
  else play(id);
}

export function play(id) {
  if (voices.has(id) || !SOUNDS[id]) return;
  const ac = context();
  if (!ac) return;

  // Cancel any end-of-ritual fade: picking a sound means the listener wants it.
  clearTimeout(fadeTimer);
  rampTo(master.gain, volume, 0.1);

  const out = ac.createGain();
  out.gain.value = 0;
  out.connect(master);
  const nodes = SOUNDS[id].build(ac, out);
  rampTo(out.gain, 1, 0.6);

  voices.set(id, { out, nodes });
  emit();
}

export function stop(id) {
  const voice = voices.get(id);
  if (!voice) return;
  voices.delete(id);
  rampTo(voice.out.gain, 0, 0.3);
  setTimeout(() => {
    voice.nodes.forEach((node) => node.stop());
    voice.out.disconnect();
  }, 2000);
  emit();
}

export function setVolume(value) {
  volume = Math.min(1, Math.max(0, value));
  if (master) rampTo(master.gain, volume, 0.05);
}

/** Slowly fades everything to silence, then stops all voices. */
export function fadeOutAll(seconds) {
  if (!master || voices.size === 0) return;
  rampTo(master.gain, 0, seconds / 5);
  clearTimeout(fadeTimer);
  fadeTimer = setTimeout(() => [...voices.keys()].forEach(stop), seconds * 1000);
}

/**
 * Creates (or resumes) the audio context. Call it from a tap so that sound
 * scheduled later, such as the midnight chime, is allowed to play.
 */
export function prime() {
  return Boolean(context());
}

/** A soft two-partial bell. `delay` (seconds) lets callers ring a short, spaced sequence. */
export function chime(delay = 0) {
  const ac = context();
  if (!ac) return;
  const t = ac.currentTime + 0.05 + delay;
  [[396, 0.12], [594, 0.05], [792, 0.03]].forEach(([freq, level]) => {
    const osc = ac.createOscillator();
    const env = ac.createGain();
    osc.frequency.value = freq;
    env.gain.setValueAtTime(0, t);
    env.gain.linearRampToValueAtTime(level, t + 0.02);
    env.gain.exponentialRampToValueAtTime(0.0001, t + 5);
    osc.connect(env).connect(ac.destination);
    osc.start(t);
    osc.stop(t + 5.1);
  });
}

// ─── Internals ──────────────────────────────────────────────────────────────

function context() {
  if (!ctx) {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return null;
    ctx = new AudioCtx();
    master = ctx.createGain();
    master.gain.value = volume;
    master.connect(ctx.destination);
  }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

function rampTo(param, value, timeConstant) {
  const t = ctx.currentTime;
  if (param.cancelAndHoldAtTime) param.cancelAndHoldAtTime(t);
  else {
    param.cancelScheduledValues(t);
    param.setValueAtTime(param.value, t);
  }
  param.setTargetAtTime(value, t, timeConstant);
}

function buildBrown(ac, out) {
  const bed = loop(ac, noise(ac, 'brown'));
  chain(bed, filter(ac, 'lowpass', 900), gain(ac, 0.55), out);
  return [bed];
}

function buildRain(ac, out) {
  const bed = loop(ac, noise(ac, 'pink'));
  const bedGain = gain(ac, 0.3);
  chain(bed, filter(ac, 'highpass', 450), filter(ac, 'lowpass', 6500), bedGain, out);
  const swell = lfo(ac, 0.07, 0.08, bedGain.gain);

  const drops = loop(ac, noise(ac, 'drops'));
  chain(drops, filter(ac, 'highpass', 1200), gain(ac, 0.35), out);
  return [bed, swell, drops];
}

function buildCabin(ac, out) {
  const hearth = loop(ac, noise(ac, 'brown'));
  const hearthGain = gain(ac, 0.5);
  chain(hearth, filter(ac, 'lowpass', 220), hearthGain, out);
  const breathe = lfo(ac, 0.2, 0.12, hearthGain.gain);

  const crackle = loop(ac, noise(ac, 'crackle'));
  chain(crackle, filter(ac, 'highpass', 700), gain(ac, 0.45), out);

  const wind = loop(ac, noise(ac, 'pink'));
  const windBand = filter(ac, 'bandpass', 380, 0.8);
  const windGain = gain(ac, 0.14);
  chain(wind, windBand, windGain, out);
  const gust = lfo(ac, 0.05, 0.09, windGain.gain);
  const sway = lfo(ac, 0.03, 160, windBand.frequency);

  return [hearth, breathe, crackle, wind, gust, sway];
}

function buildSnow(ac, out) {
  const drift = loop(ac, noise(ac, 'pink'));
  const driftGain = gain(ac, 0.16);
  chain(drift, filter(ac, 'highpass', 900), filter(ac, 'lowpass', 4200), driftGain, out);
  const swell = lfo(ac, 0.04, 0.07, driftGain.gain);

  const hush = loop(ac, noise(ac, 'brown'));
  const hushBand = filter(ac, 'lowpass', 320);
  chain(hush, hushBand, gain(ac, 0.28), out);
  const sway = lfo(ac, 0.025, 90, hushBand.frequency);

  return [drift, swell, hush, sway];
}

// Node helpers

function loop(ac, buffer) {
  const src = ac.createBufferSource();
  src.buffer = buffer;
  src.loop = true;
  // Random offset so layers sharing a buffer never line up.
  src.start(ac.currentTime, Math.random() * buffer.duration);
  return src;
}

function filter(ac, type, frequency, Q = 0.707) {
  const node = ac.createBiquadFilter();
  node.type = type;
  node.frequency.value = frequency;
  node.Q.value = Q;
  return node;
}

function gain(ac, value) {
  const node = ac.createGain();
  node.gain.value = value;
  return node;
}

function lfo(ac, rate, depth, param) {
  const osc = ac.createOscillator();
  osc.frequency.value = rate;
  osc.connect(gain(ac, depth)).connect(param);
  osc.start();
  return osc;
}

const chain = (...nodes) => nodes.reduce((from, to) => from.connect(to));

// Buffer generation (stereo, generated once per session)

const GENERATORS = {
  brown: [8, fillBrown],
  pink: [8, fillPink],
  drops: [6, fillDrops],
  crackle: [12, fillCrackle],
};

function noise(ac, kind) {
  if (!buffers[kind]) {
    const [seconds, fill] = GENERATORS[kind];
    const length = Math.floor(seconds * ac.sampleRate);
    const buffer = ac.createBuffer(2, length, ac.sampleRate);
    for (let ch = 0; ch < 2; ch++) fill(buffer.getChannelData(ch), ac.sampleRate);
    buffers[kind] = buffer;
  }
  return buffers[kind];
}

const white = () => Math.random() * 2 - 1;

/** Removes the DC step between the last and first sample so the loop point is silent. */
function seamless(data) {
  const step = (data[data.length - 1] - data[0]) / (data.length - 1);
  for (let i = 0; i < data.length; i++) data[i] -= step * i;
}

function fillBrown(data) {
  let last = 0;
  for (let i = 0; i < data.length; i++) {
    last = (last + 0.02 * white()) / 1.02;
    data[i] = last * 3.5;
  }
  seamless(data);
}

// Paul Kellet's economy pink-noise filter.
function fillPink(data) {
  let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
  for (let i = 0; i < data.length; i++) {
    const w = white();
    b0 = 0.99886 * b0 + w * 0.0555179;
    b1 = 0.99332 * b1 + w * 0.0750759;
    b2 = 0.969 * b2 + w * 0.153852;
    b3 = 0.8665 * b3 + w * 0.3104856;
    b4 = 0.55 * b4 + w * 0.5329522;
    b5 = -0.7616 * b5 - w * 0.016898;
    data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.11;
    b6 = w * 0.115926;
  }
  seamless(data);
}

/** Hundreds of tiny decaying "plinks" per second read as rain patter. */
function fillDrops(data, sampleRate) {
  const count = (data.length / sampleRate) * 220;
  for (let k = 0; k < count; k++) {
    const tau = (0.002 + Math.random() * 0.004) * sampleRate;
    const span = Math.floor(tau * 6);
    const start = Math.floor(Math.random() * (data.length - span));
    const omega = (2 * Math.PI * (1800 + Math.random() * 4200)) / sampleRate;
    const amp = Math.random() ** 3 * 0.5;
    for (let j = 0; j < span; j++) data[start + j] += amp * Math.exp(-j / tau) * Math.sin(omega * j);
  }
}

/** Clusters of sharp noise clicks, occasionally a louder pop, read as a wood fire. */
function fillCrackle(data, sampleRate) {
  const clusters = (data.length / sampleRate) * 4;
  for (let c = 0; c < clusters; c++) {
    const at = Math.floor(Math.random() * (data.length - sampleRate * 0.2));
    const clicks = 1 + Math.floor(Math.random() * 6);
    for (let k = 0; k < clicks; k++) {
      const tau = (0.0005 + Math.random() * 0.002) * sampleRate;
      const start = at + Math.floor(Math.random() * 0.08 * sampleRate);
      const amp = (0.2 + Math.random() * 0.8) * (Math.random() < 0.15 ? 1 : 0.4);
      for (let j = 0; j < tau * 8; j++) data[start + j] += amp * Math.exp(-j / tau) * white();
    }
  }
}
