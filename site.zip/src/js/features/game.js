import { store } from '../core/store.js';
import { CARDS, cardById, FINALE, INTENTION_DEFAULTS } from './content.js';

/**
 * Game state: one object in the store, written on every change so a reload,
 * a locked phone or a closed tab always resumes exactly where play stopped.
 *
 * The Clear the slate round has no state here on purpose. Its words live only in
 * that round's view and are never written anywhere.
 */

export const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
  'August', 'September', 'October', 'November', 'December'];

export const getGame = () => store.get().game;

export function updateGame(patch) {
  store.set(({ game }) => ({ game: game && { ...game, ...(typeof patch === 'function' ? patch(game) : patch) } }));
}

/**
 * Which year is closing and which is opening. December and January are the
 * season; any other day the game looks back over the last twelve months.
 */
export function yearContext(now = new Date()) {
  const m = now.getMonth();
  const y = now.getFullYear();
  if (m === 11) return { closingYear: y, newYear: y + 1, inSeason: true };
  if (m === 0) return { closingYear: y - 1, newYear: y, inSeason: true };
  return { closingYear: y, newYear: y + 1, inSeason: false };
}

export function yearLabel({ closingYear, newYear, inSeason }) {
  return inSeason ? `${closingYear} → ${newYear}` : 'Twelve months · one fresh start';
}

/** In season: January to December of the closing year. Otherwise the twelve months ending now. */
export function monthList(now = new Date()) {
  const { closingYear, inSeason } = yearContext(now);
  if (inSeason) return MONTHS.map((_, m) => ({ m, y: closingYear }));
  return Array.from({ length: 12 }, (_, k) => {
    const d = new Date(now.getFullYear(), now.getMonth() - 11 + k, 1);
    return { m: d.getMonth(), y: d.getFullYear() };
  });
}

/** The next December 31st. In December that is next year's, so a letter never opens days later. */
export function defaultRevealDate(now = new Date()) {
  const y = now.getMonth() === 11 ? now.getFullYear() + 1 : now.getFullYear();
  return `${y}-12-31`;
}

function shuffle(list) {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function newGame(now = new Date()) {
  const ctx = yearContext(now);
  const game = {
    id: `g${now.getTime().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    startedAt: now.getTime(),
    ...ctx,
    round: 1,
    scene: { sound: null, dress: null, candle: false },
    months: monthList(now).map(({ m, y }) => ({ m, y, chip: null, text: '', skipped: false })),
    monthAt: 0,
    stars: null,
    deck: shuffle(CARDS.map((c) => c.id)),
    cards: [],
    answers: {},
    word: null,
    wordCustom: false,
    intentions: INTENTION_DEFAULTS.map(({ label }) => ({ label, text: '' })),
    letterDraft: '',
    revealOn: defaultRevealDate(now),
    letterId: null,
    letterSkipped: false,
    archivedId: null,
  };
  game.cards = dealCards(game);
  store.set({ game });
  return game;
}

export function clearGame() {
  store.set({ game: null });
}

export const isFinale = (game) => game?.round >= FINALE;

// ─── Cards ────────────────────────────────────────────────────────────────────

/** Next unused card from the shuffled deck, preferring a category not already on the table. */
function nextCard(game, cards) {
  const used = new Set([...cards.map((c) => c.id), ...(game.usedCards ?? [])]);
  const cats = new Set(cards.map((c) => cardById(c.id).cat));
  const fresh = game.deck.filter((id) => !used.has(id));
  return fresh.find((id) => !cats.has(cardById(id).cat)) ?? fresh[0] ?? game.deck[0];
}

function dealCards(game) {
  const cards = [];
  for (let slot = 0; slot < 3; slot++) cards.push({ id: nextCard(game, cards), flipped: false, redrawn: false });
  return cards;
}

export function flipCard(slot) {
  updateGame((g) => ({ cards: g.cards.map((c, i) => (i === slot ? { ...c, flipped: true } : c)) }));
}

/** Each slot may be redrawn once per round. */
export function redrawCard(slot) {
  updateGame((g) => {
    const current = g.cards[slot];
    if (!current || current.redrawn) return {};
    const others = g.cards.filter((_, i) => i !== slot);
    const usedCards = [...(g.usedCards ?? []), current.id];
    const id = nextCard({ ...g, usedCards }, others);
    return {
      usedCards,
      cards: g.cards.map((c, i) => (i === slot ? { id, flipped: true, redrawn: true } : c)),
    };
  });
}

// ─── Highlights & archive ─────────────────────────────────────────────────────

export const monthEntryText = (entry) => (entry.text || '').trim() || entry.chip || '';

/** The three highlights for the share card: starred months, else the first three filled. */
export function highlightIndexes(game) {
  const filled = game.months.map((e, i) => (monthEntryText(e) ? i : -1)).filter((i) => i >= 0);
  if (game.stars?.length) return game.stars.filter((i) => filled.includes(i)).slice(0, 3);
  return filled.slice(0, 3);
}

export function highlights(game) {
  return highlightIndexes(game).map((i) => ({ month: MONTHS[game.months[i].m], text: monthEntryText(game.months[i]) }));
}

/**
 * The archive entry is everything the share card may show, and nothing more:
 * no card answers, no letter, and the Clear the slate round never reaches state at all.
 */
export function archiveEntry(game, now = Date.now()) {
  return {
    id: game.id,
    completedAt: now,
    closingYear: game.closingYear,
    newYear: game.newYear,
    inSeason: game.inSeason,
    yearLabel: yearLabel(game),
    word: game.word ?? '',
    intentions: game.intentions.map(({ label, text }) => ({ label: label.trim() || 'Intention', text: text.trim() })),
    highlights: highlights(game),
    checkins: {},
  };
}

export function archiveGame(game) {
  store.set(({ archive }) => {
    const prior = archive.find((e) => e.id === game.id);
    const entry = { ...archiveEntry(game, prior?.completedAt ?? Date.now()), checkins: prior?.checkins ?? {} };
    return { archive: [entry, ...archive.filter((e) => e.id !== game.id)] };
  });
  updateGame({ archivedId: game.id });
}

export const latestEntry = () =>
  [...store.get().archive].sort((a, b) => b.completedAt - a.completedAt)[0] ?? null;
