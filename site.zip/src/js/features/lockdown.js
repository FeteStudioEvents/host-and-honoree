const NIGHT = '#16151b';

/**
 * Switches the whole app between idle, active, and complete ritual modes.
 * The `data-ritual` attribute drives the night palette and hides app chrome (see ritual.css).
 */
export function setRitualMode(mode) {
  const root = document.documentElement;
  if (mode === 'idle') delete root.dataset.ritual;
  else root.dataset.ritual = mode;

  for (const meta of document.querySelectorAll('meta[name="theme-color"]')) {
    meta.dataset.default ??= meta.content;
    meta.content = mode === 'idle' ? meta.dataset.default : NIGHT;
  }
}

/**
 * Engages focus lockdown for an active ritual:
 * - goes fullscreen where the browser allows it (needs a user gesture; iPhone Safari never allows it)
 * - asks for confirmation before the tab is closed or reloaded
 * - reports how long the user was away whenever they come back to the app
 *
 * Returns a release function.
 */
export function engageLockdown({ requestFullscreen = false, onReturn } = {}) {
  const root = document.documentElement;
  if (requestFullscreen && root.requestFullscreen && !document.fullscreenElement) {
    root.requestFullscreen({ navigationUI: 'hide' }).catch(() => {});
  }

  let hiddenAt = null;
  const onVisibility = () => {
    if (document.hidden) {
      hiddenAt = Date.now();
    } else if (hiddenAt) {
      const away = Date.now() - hiddenAt;
      hiddenAt = null;
      onReturn?.(away);
    }
  };
  const onBeforeUnload = (event) => {
    event.preventDefault();
    event.returnValue = '';
  };

  document.addEventListener('visibilitychange', onVisibility);
  window.addEventListener('beforeunload', onBeforeUnload);

  return function release() {
    document.removeEventListener('visibilitychange', onVisibility);
    window.removeEventListener('beforeunload', onBeforeUnload);
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  };
}
