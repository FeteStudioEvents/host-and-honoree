/**
 * Game content. Every prompt, word and card here is original to Fête Studio Events.
 * House rules: no song, film or book titles, no brand names, no therapy or medical
 * language, and nothing that assumes a partner, family or alcohol.
 */

export const ROUNDS = [
  { n: 1, key: 'scene', name: 'Set the scene', short: 'Scene' },
  { n: 2, key: 'reel', name: 'Highlight reel', short: 'Reel' },
  { n: 3, key: 'cards', name: 'The card draw', short: 'Cards' },
  { n: 4, key: 'letgo', name: 'Clear the slate', short: 'Clear' },
  { n: 5, key: 'word', name: 'Word of the year', short: 'Word' },
  { n: 6, key: 'letter', name: 'Letter to future you', short: 'Letter' },
];
export const FINALE = 7;

/** Soundscapes reuse the ambient engine's voices under party-night names. */
export const SOUNDSCAPES = [
  { id: 'cabin', label: 'Fireside', note: 'Crackle and a low hearth' },
  { id: 'snow', label: 'Soft snow', note: 'Hushed wind, soft drift' },
  { id: 'rain', label: 'Rain on glass', note: 'A soft, steady patter' },
  { id: 'brown', label: 'Deep hush', note: 'A warm, even quiet' },
  { id: 'none', label: 'Silence', note: 'Just you and the clock' },
];

export const DRESS_CODES = [
  { id: 'sequins', label: 'Sequins & slippers', note: 'Sparkle on top, comfort below.' },
  { id: 'formal-pjs', label: 'Pajamas, but formal', note: 'Every button buttoned.' },
  { id: 'gold', label: 'One thing gold', note: 'A sock absolutely counts.' },
  { id: 'sweater', label: 'The favorite sweater', note: 'The one with stories in it.' },
  { id: 'mono', label: 'Midnight monochrome', note: 'One color, head to toe.' },
  { id: 'as-you-are', label: 'Exactly as you are', note: 'You’re already dressed for it.' },
];

/** Memory chips for the highlight reel. Each month shows six, rotating through the set. */
export const MEMORY_CHIPS = [
  'A small win', 'Time outside', 'A great meal', 'Someone new', 'A trip, near or far',
  'Rest, finally', 'A brave yes', 'Learned something', 'Hard but worth it', 'Laughed a lot',
  'A cozy stretch', 'A fresh start', 'Busy and full', 'Quiet and good', 'Made something',
  'A celebration', 'Moved my body', 'Good news',
];

export function chipsForMonth(index) {
  const out = [];
  for (let k = 0; k < 6; k++) out.push(MEMORY_CHIPS[(index * 5 + k * 3) % MEMORY_CHIPS.length]);
  return [...new Set(out)];
}

export const CATEGORIES = {
  proud: { label: 'Proud', color: 'gold' },
  learned: { label: 'Learned', color: 'sky' },
  surprised: { label: 'Surprised', color: 'blush' },
  grateful: { label: 'Grateful', color: 'sage' },
  letgo: { label: 'Let go', color: 'lavender' },
};

const PROMPTS = {
  proud: [
    'What did you do this year that past-you would not have believed?',
    'When did you keep a promise to yourself?',
    'What hard thing did you finish, even if nobody clapped?',
    'When did you speak up, even with a shaky voice?',
    'What small, daily thing did you keep showing up for?',
    'Which choice this year felt the most like you?',
    'What did you make, build or fix with your own hands or mind?',
    'When were you kind when it would have been easier not to be?',
    'What boundary did you hold that protected your peace?',
    'What can you do now that you couldn’t do last winter?',
    'If someone who cheers for you gave a toast tonight, what would they mention?',
    'What “no” did you say that made room for a better “yes”?',
  ],
  learned: [
    'What did this year teach you about how you like to spend your time?',
    'What’s one opinion you changed your mind about?',
    'What did you learn the hard way that you’d happily pass on?',
    'What did you pick up just because you were curious?',
    'What did rest teach you this year?',
    'What did you discover about the people you feel at home with?',
    'What did you need more of than you expected? Less of?',
    'Which mistake turned out to be a good teacher?',
    'What did you learn about asking for help?',
    'What piece of advice finally made sense?',
    'When in the day do you feel most like yourself?',
    'What did you learn about the way you handle change?',
  ],
  surprised: [
    'What turned out better than you expected?',
    'What took you by surprise, in the best way?',
    'Who surprised you with their kindness?',
    'Which ordinary day became unexpectedly memorable?',
    'What did you enjoy that you thought you wouldn’t?',
    'When did you surprise yourself?',
    'Which plan fell through and opened a better door?',
    'What new favorite showed up out of nowhere?',
    'What made you laugh harder than you had in ages?',
    'What did you stop worrying about without even noticing?',
    'Which place, near or far, surprised you?',
    'What question did this year answer that you didn’t know you were asking?',
  ],
  grateful: [
    'Who made this year lighter, even a little?',
    'Which everyday comfort deserves a thank-you note?',
    'What did your body carry you through this year?',
    'Which message, call or note do you still think about?',
    'What corner of your home or space are you grateful for?',
    'What simple pleasure did you return to again and again?',
    'Who did you get to know better this year?',
    'What do you have now that you once only hoped for?',
    'What sound, smell or taste will always mean this year to you?',
    'Which earlier version of you deserves a thank-you tonight?',
    'Which opportunity are you glad you said yes to?',
    'What helped you through a hard day?',
  ],
  letgo: [
    'Which expectation are you ready to set down?',
    'What habit has finished its job?',
    'What story about yourself is out of date?',
    'What are you done apologizing for?',
    'What would you stop carrying if no one would notice?',
    'What did you outgrow this year?',
    'Which worry turned out to be mostly noise?',
    'Which comparison is it time to retire?',
    'Which “should” could become a “could”?',
    'What unfinished thing can you call finished, just as it is?',
    'What would feel lighter if you forgave it, or yourself?',
    'What are you making room for?',
  ],
};

/** 60 reflection cards: { id: 'proud-0', cat: 'proud', text }. */
export const CARDS = Object.entries(PROMPTS).flatMap(([cat, list]) =>
  list.map((text, i) => ({ id: `${cat}-${i}`, cat, text })),
);
export const cardById = (id) => CARDS.find((c) => c.id === id);

/** 80 intention words for the spin. */
export const WORDS = [
  'Bloom', 'Steady', 'Brave', 'Ease', 'Root', 'Spark', 'Gather', 'Soften',
  'Rise', 'Savor', 'Wander', 'Anchor', 'Clarity', 'Play', 'Begin', 'Nourish',
  'Trust', 'Open', 'Build', 'Linger', 'Shine', 'Breathe', 'Kindle', 'Tend',
  'Momentum', 'Wonder', 'Ground', 'Flourish', 'Grace', 'Courage', 'Balance', 'Joy',
  'Focus', 'Simplify', 'Expand', 'Rest', 'Create', 'Connect', 'Discover', 'Release',
  'Thrive', 'Settle', 'Bold', 'Gentle', 'Patience', 'Light', 'Hope', 'Plenty',
  'Return', 'Listen', 'Unfold', 'Ripen', 'Presence', 'Delight', 'Renew', 'Stretch',
  'Glow', 'Harvest', 'Devotion', 'Freedom', 'Home', 'Curious', 'Wild', 'Quiet',
  'Commit', 'Repair', 'Lift', 'Practice', 'Steep', 'Roam', 'Fierce', 'Tender',
  'Rhythm', 'Craft', 'Generous', 'Awake', 'Shimmer', 'Sturdy', 'Wholehearted', 'Horizon',
];

export const INTENTION_DEFAULTS = [
  { label: 'Body', placeholder: 'e.g. A walk after lunch, most days' },
  { label: 'Mind', placeholder: 'e.g. One new thing a month' },
  { label: 'Life', placeholder: 'e.g. Say yes to more small adventures' },
];

/** Lines shown at midnight. */
export const MIDNIGHT_LINES = [
  'Raise whatever’s in your glass. Sparkling anything counts.',
  'Here’s to the host, and to the guest of honor.',
];

export const CHECKIN_MOODS = [
  { id: 'growing', label: 'Growing' },
  { id: 'steady', label: 'Steady' },
  { id: 'reset', label: 'Ready for a reset' },
];
