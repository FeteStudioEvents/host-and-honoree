import { dayKey } from '../core/clock.js';
import { store } from '../core/store.js';

/**
 * Letters to future you. Stored only on this device, and kept sealed until the
 * local calendar date reaches `revealOn`. Views re-check on the clock's
 * day-change event, so a letter opens at midnight even with the app left open.
 */

export const getLetters = () => store.get().letters;
export const getLetter = (id) => getLetters().find((l) => l.id === id) ?? null;

/** 'YYYY-MM-DD' strings sort the same way as the dates they name. */
export const isOpenable = (letter, today = dayKey()) => Boolean(letter) && today >= letter.revealOn;

export function sealLetter({ text, revealOn, gameId }) {
  const letter = {
    id: `l${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    text,
    revealOn,
    gameId: gameId ?? null,
    sealedAt: Date.now(),
    openedAt: null,
  };
  store.set(({ letters }) => ({ letters: [...letters, letter] }));
  return letter;
}

export function markOpened(id) {
  store.set(({ letters }) => ({
    letters: letters.map((l) => (l.id === id && !l.openedAt ? { ...l, openedAt: Date.now() } : l)),
  }));
}

export function deleteLetter(id) {
  store.set(({ letters }) => ({ letters: letters.filter((l) => l.id !== id) }));
}

/** Local midnight at the start of a 'YYYY-MM-DD' day. */
export function startOfDay(key) {
  const [y, m, d] = key.split('-').map(Number);
  return new Date(y, m - 1, d);
}

export function formatDate(key, opts = { month: 'long', day: 'numeric', year: 'numeric' }) {
  return startOfDay(key).toLocaleDateString(undefined, opts);
}

/** "312 days to go", "Opens tomorrow", "Opens in 5 h 12 min". */
export function countdownText(letter, now = new Date()) {
  if (isOpenable(letter, dayKey(now))) return 'Ready to open';
  const ms = startOfDay(letter.revealOn) - now;
  const minutes = Math.ceil(ms / 60000);
  if (minutes < 60) return `Opens in ${minutes} min`;
  if (minutes < 24 * 60) return `Opens in ${Math.floor(minutes / 60)} h ${minutes % 60} min`;
  const days = Math.round((startOfDay(letter.revealOn) - startOfDay(dayKey(now))) / 86400000);
  return days === 1 ? 'Opens tomorrow' : `${days.toLocaleString()} days to go`;
}

/** Valid future date for the reveal picker, as 'YYYY-MM-DD'. */
export function tomorrowKey(now = new Date()) {
  const t = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  return dayKey(t);
}
