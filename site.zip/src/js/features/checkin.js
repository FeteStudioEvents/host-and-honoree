import { store } from '../core/store.js';
import { latestEntry } from './game.js';

/**
 * Monthly intentions check-in. No notifications: the prompt simply appears on
 * the home screen the first time the app is opened in a new month, starting
 * the month after the game was finished (and, for a New Year game, from January).
 */

export const monthKey = (date = new Date()) =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;

export function pendingCheckin(now = new Date()) {
  const entry = latestEntry();
  if (!entry || !entry.intentions.some((i) => i.text)) return null;
  const month = monthKey(now);
  if (month <= monthKey(new Date(entry.completedAt))) return null;
  if (entry.inSeason && month < `${entry.newYear}-01`) return null;
  if (entry.checkins?.[month]) return null;
  return { entry, month };
}

/** Saves a check-in (or a "not this month") so the prompt waits for next month. */
export function recordCheckin(entryId, month, data) {
  store.set(({ archive }) => ({
    archive: archive.map((e) => (e.id === entryId
      ? { ...e, checkins: { ...e.checkins, [month]: { ...data, at: Date.now() } } }
      : e)),
  }));
}

export function monthLabel(month) {
  const [y, m] = month.split('-').map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString(undefined, { month: 'long' });
}
