import { html, render, qs } from '../core/dom.js';
import * as ambient from './ambient.js';
import { MIDNIGHT_LINES } from './content.js';
import { engageLockdown, setRitualMode } from './lockdown.js';
import { reducedMotion } from './motion.js';

/**
 * Full-screen countdowns.
 *
 * Midnight mode: on December 31st from 11:00 PM local time, counts down to the
 * real local midnight. Any other time, "your midnight" is a ten-second countdown
 * the player can run whenever they like. Both end with a gentle chime.
 */

export const PERSONAL_MS = 10_000;

export function isMidnightWindow(now = new Date()) {
  return now.getMonth() === 11 && now.getDate() === 31 && now.getHours() >= 23;
}

const nextMidnight = (now = new Date()) => new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);

function format(ms) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const pad = (n) => String(n).padStart(2, '0');
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return h ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}

/**
 * Opens the countdown. `mode` is 'midnight' or 'personal'.
 * Call it from a tap: that tap is what allows the chime to play later.
 */
export function openCountdown({ mode, newYear, onClose } = {}) {
  ambient.prime();
  const target = mode === 'midnight' ? nextMidnight().getTime() : Date.now() + PERSONAL_MS;
  const yearText = mode === 'midnight' ? String(new Date(target).getFullYear()) : (newYear ? String(newYear) : '');
  const opener = document.activeElement;

  const dialog = document.createElement('dialog');
  dialog.className = 'midnight';
  dialog.dataset.mode = mode;
  dialog.dataset.state = 'counting';
  dialog.setAttribute('aria-labelledby', 'midnight-title');
  render(dialog, html`
    <div class="midnight__burst" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i></div>
    <div class="midnight__body">
      <p class="eyebrow" id="midnight-title">${mode === 'midnight' ? 'Midnight mode' : 'Your midnight'}</p>
      <div class="midnight__clock" role="timer" aria-label="Time until midnight" data-el="clock">${format(target - Date.now())}</div>
      <p class="midnight__caption serif" data-el="caption">${mode === 'midnight'
        ? `Counting you into ${yearText}. Get your glass ready — sparkling anything.`
        : 'Ten seconds, on your own schedule. Get your glass ready — sparkling anything.'}</p>
      <p class="sr-only" aria-live="assertive" data-el="announce"></p>
      <button class="btn btn--ghost midnight__close" type="button" data-el="close">Close</button>
    </div>
  `);
  document.body.append(dialog);

  setRitualMode('active');
  const release = engageLockdown({ requestFullscreen: false });
  dialog.showModal();
  // Fullscreen goes on the dialog itself: a fullscreen <html> would be stacked above the modal.
  if (dialog.requestFullscreen && !document.fullscreenElement) dialog.requestFullscreen({ navigationUI: 'hide' }).catch(() => {});
  qs('[data-el="close"]', dialog).focus();

  const clockEl = qs('[data-el="clock"]', dialog);
  const announce = (msg) => { qs('[data-el="announce"]', dialog).textContent = msg; };
  let lastShown = null;
  let done = false;
  announce(mode === 'midnight' ? `Midnight mode. ${format(target - Date.now())} to go.` : 'Ten-second countdown started.');

  const tick = () => {
    const ms = target - Date.now();
    const shown = format(ms);
    if (shown !== lastShown) {
      lastShown = shown;
      clockEl.textContent = shown;
      const secs = Math.ceil(ms / 1000);
      if (secs <= 10 && secs > 0) {
        dialog.dataset.final = '';
        if (secs <= 3 || secs === 10 || secs === 5) announce(String(secs));
      }
    }
    if (ms <= 0 && !done) finish();
  };

  function finish() {
    done = true;
    clearInterval(timer);
    clockEl.textContent = '00:00';
    dialog.dataset.state = 'done';
    dialog.dataset.endedAt = String(Date.now());
    const caption = qs('[data-el="caption"]', dialog);
    const title = mode === 'midnight' ? `Happy New Year${yearText ? `, ${yearText}` : ''}.` : 'Happy new year, you.';
    caption.textContent = `${title} ${MIDNIGHT_LINES[0]}`;
    announce(title);
    if (!reducedMotion()) dialog.classList.add('midnight--burst');
    [0, 1.4, 2.8].forEach((delay) => ambient.chime(delay));
  }

  const timer = setInterval(tick, 200);
  tick();

  function close() {
    clearInterval(timer);
    release();
    setRitualMode('idle');
    dialog.close();
    dialog.remove();
    if (opener?.isConnected) opener.focus();
    onClose?.({ finished: done });
  }

  qs('[data-el="close"]', dialog).addEventListener('click', close);
  dialog.addEventListener('cancel', (e) => {
    e.preventDefault();
    close();
  });

  return { close, dialog };
}
