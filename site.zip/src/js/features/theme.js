import { store } from '../core/store.js';

/** Night is the default; cream paper is one tap away. */
const META = { dark: '#14131b', light: '#f6f2ee' };

export function applyTheme(theme = store.get().theme) {
  const t = theme === 'light' ? 'light' : 'dark';
  document.documentElement.dataset.theme = t;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) {
    meta.content = META[t];
    meta.dataset.default = META[t];
  }
  return t;
}

export function toggleTheme() {
  const next = store.get().theme === 'light' ? 'dark' : 'light';
  store.set({ theme: next });
  return applyTheme(next);
}
