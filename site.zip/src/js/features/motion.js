/** True when the person has asked their device for less motion. */
export const reducedMotion = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;

/** Resolves after `ms`, or straight away when motion is reduced. */
export const settle = (ms) => new Promise((resolve) => setTimeout(resolve, reducedMotion() ? 0 : ms));
