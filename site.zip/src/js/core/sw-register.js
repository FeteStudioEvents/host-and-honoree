import { toast } from './toast.js';

/**
 * Registers the service worker and manages updates.
 *
 * A new version installs in the background, then waits. The user is offered a
 * "Refresh"; only then does the new worker take over and the page reload, so
 * a session never runs half old files and half new ones. Offers are held back
 * while a ritual is running.
 */
export function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  if (location.hostname === 'localhost' && new URLSearchParams(location.search).has('nosw')) return;

  window.addEventListener('load', async () => {
    let reg;
    try {
      reg = await navigator.serviceWorker.register('sw.js', { updateViaCache: 'none' });
    } catch (err) {
      console.warn('[sw] registration failed', err);
      return;
    }
    if (!reg) return; // some embedded browsers and test harnesses resolve without a registration

    requestPersistentStorage();

    let reloading = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (reloading) location.reload();
    });

    const offer = (worker) => offerUpdate(() => {
      reloading = true;
      worker.postMessage({ type: 'SKIP_WAITING' });
    });

    if (reg.waiting && navigator.serviceWorker.controller) offer(reg.waiting);
    reg.addEventListener('updatefound', () => {
      const worker = reg.installing;
      worker?.addEventListener('statechange', () => {
        if (worker.state === 'installed' && navigator.serviceWorker.controller) offer(worker);
      });
    });

    // Installed apps can stay open for days; check for a new version each time they come back.
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') reg.update().catch(() => {});
    });
  });
}

function offerUpdate(apply) {
  const root = document.documentElement;
  const show = () => toast('A fresh version is ready.', { action: 'Refresh', onAction: apply, duration: 0 });
  if (!root.dataset.ritual) return show();

  const observer = new MutationObserver(() => {
    if (!root.dataset.ritual) {
      observer.disconnect();
      show();
    }
  });
  observer.observe(root, { attributes: true, attributeFilter: ['data-ritual'] });
}

/** Asks the browser not to evict our caches and journal under storage pressure. */
async function requestPersistentStorage() {
  try {
    if (navigator.storage?.persist && !(await navigator.storage.persisted())) await navigator.storage.persist();
  } catch {
    // Best effort only.
  }
}
