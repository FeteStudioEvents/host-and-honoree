const ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

export const escape = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ESCAPES[ch]);

/** Marks a string as pre-escaped so `html` won't escape it again. */
export const raw = (value) => ({ __raw: String(value) });

/**
 * Tagged template that escapes interpolations by default.
 * Arrays are joined; values wrapped in raw() or produced by html`` pass through.
 */
export function html(strings, ...values) {
  const out = strings.reduce((acc, str, i) => {
    if (i === 0) return str;
    return acc + toMarkup(values[i - 1]) + str;
  }, '');
  return raw(out);
}

function toMarkup(value) {
  if (value == null || value === false) return '';
  if (Array.isArray(value)) return value.map(toMarkup).join('');
  if (typeof value === 'object' && '__raw' in value) return value.__raw;
  return escape(value);
}

/** Replaces the contents of `root` with markup from html``. */
export function render(root, markup) {
  root.innerHTML = toMarkup(markup);
}

export const qs = (selector, root = document) => root.querySelector(selector);
export const qsa = (selector, root = document) => [...root.querySelectorAll(selector)];

/** Delegated event listener. Returns an unsubscribe function. */
export function on(root, type, selector, handler) {
  const listener = (event) => {
    const target = event.target.closest(selector);
    if (target && root.contains(target)) handler(event, target);
  };
  root.addEventListener(type, listener);
  return () => root.removeEventListener(type, listener);
}
