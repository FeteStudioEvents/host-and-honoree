import { html, on, render } from '../core/dom.js';
import { store } from '../core/store.js';
import { toast } from '../core/toast.js';
import { CHECKIN_MOODS } from '../features/content.js';
import { monthLabel } from '../features/checkin.js';
import { newGame } from '../features/game.js';
import { exportShareCard } from '../features/share-card.js';

export const title = 'Past years';

const moodLabel = (id) => CHECKIN_MOODS.find((m) => m.id === id)?.label ?? '';

function entryTemplate(e) {
  const checkins = Object.entries(e.checkins ?? {}).filter(([, c]) => !c.skipped).sort(([a], [b]) => a.localeCompare(b));
  return html`
    <article class="card stack archive-entry" aria-labelledby="ae-${e.id}">
      <p class="eyebrow">${e.yearLabel}</p>
      <h2 class="serif word-display" id="ae-${e.id}">${e.word || 'No word chosen'}</h2>
      <p class="text-xs text-muted">Finished ${new Date(e.completedAt).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}</p>
      ${e.intentions.some((i) => i.text) ? html`<ul class="intent-list">
        ${e.intentions.filter((i) => i.text).map((i) => html`<li><span class="eyebrow eyebrow--muted">${i.label}</span><span>${i.text}</span></li>`)}
      </ul>` : ''}
      ${e.highlights.length ? html`<ul class="highlight-list">
        ${e.highlights.map((h) => html`<li><span class="eyebrow eyebrow--muted">${h.month}</span> <span class="serif">${h.text}</span></li>`)}
      </ul>` : ''}
      ${checkins.length ? html`<details class="checkins">
        <summary>Check-ins (${checkins.length})</summary>
        <ul>${checkins.map(([month, c]) => html`<li><strong>${monthLabel(month)}</strong>: ${
          e.intentions.filter((i) => i.text).map((i, idx) => `${i.label} ${moodLabel(c.moods?.[idx]) || '—'}`).join(' · ')}</li>`)}</ul>
      </details>` : ''}
      <button class="btn btn--ghost" type="button" data-export="${e.id}">Save this card</button>
    </article>`;
}

export function mount(root, { navigate }) {
  const { archive, game } = store.get();
  const sorted = [...archive].sort((a, b) => b.completedAt - a.completedAt);
  render(root, html`
    <div class="stack stack-lg fade-in">
      <header class="stack stack-sm">
        <p class="eyebrow">Archive</p>
        <h1 tabindex="-1">Past years</h1>
        <p class="text-muted">Every game you finish is kept here on this device, with its card and intentions.</p>
      </header>
      ${sorted.length ? sorted.map(entryTemplate) : html`<p class="serif text-lg">Nothing here yet. Your first finished game will appear here.</p>`}
      <div class="stack stack-sm">
        <button class="btn btn--lux" type="button" data-action="play">${game ? 'Resume your game' : 'Play again'}</button>
        <a class="btn btn--ghost" href="#/">Back home</a>
      </div>
    </div>`);

  const offExport = on(root, 'click', '[data-export]', async (_, btn) => {
    const entry = store.get().archive.find((e) => e.id === btn.dataset.export);
    if (!entry) return;
    btn.disabled = true;
    try {
      const result = await exportShareCard(entry);
      if (result === 'downloaded') toast('Card saved to your downloads.');
    } finally {
      btn.disabled = false;
    }
  });
  const offPlay = on(root, 'click', '[data-action="play"]', () => {
    if (!store.get().game) newGame();
    navigate('/play');
  });
  return () => {
    offExport();
    offPlay();
  };
}
