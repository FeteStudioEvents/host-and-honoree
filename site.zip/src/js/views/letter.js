import { clock } from '../core/clock.js';
import { html, on, qs, render } from '../core/dom.js';
import { countdownText, formatDate, getLetter, isOpenable, markOpened } from '../features/letters.js';
import { envelopeArt } from './art.js';

export const title = 'Your letter';

/**
 * A sealed letter's text is never put in the page before its date: the sealed
 * state renders only the envelope and the countdown.
 */
function template(letter, revealed) {
  if (!letter) {
    return html`<section class="center stack mt-6">
      <h1>No letter here</h1>
      <p class="text-muted">It may have been erased from this device.</p>
      <a class="btn" href="#/">Back home</a>
    </section>`;
  }
  if (!isOpenable(letter, clock.today())) {
    return html`
      <section class="letter-view stack center fade-in" data-state="sealed" aria-labelledby="letter-title">
        <div class="sealed__art">${envelopeArt()}</div>
        <p class="eyebrow">Sealed ${new Date(letter.sealedAt).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}</p>
        <h1 id="letter-title" tabindex="-1">Not yet</h1>
        <p class="serif text-lg">This letter opens on ${formatDate(letter.revealOn)}.</p>
        <p class="text-muted" data-el="countdown">${countdownText(letter)}</p>
        <a class="btn btn--ghost" href="#/">Back home</a>
      </section>`;
  }
  if (!revealed && !letter.openedAt) {
    return html`
      <section class="letter-view stack center fade-in" data-state="ready" aria-labelledby="letter-title">
        <div class="sealed__art">${envelopeArt()}</div>
        <p class="eyebrow">From you, ${new Date(letter.sealedAt).toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}</p>
        <h1 id="letter-title" tabindex="-1">Your letter is ready</h1>
        <p class="text-muted">Find a quiet minute. It’s been waiting for you.</p>
        <button class="btn btn--lux" type="button" data-action="open">Open the letter</button>
      </section>`;
  }
  return html`
    <article class="letter-view letter-view--open stack fade-in" data-state="open" aria-labelledby="letter-title">
      <p class="eyebrow">Written ${new Date(letter.sealedAt).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}</p>
      <h1 id="letter-title" tabindex="-1" class="serif">Dear future me,</h1>
      <div class="letter-paper letter-paper--read serif" data-el="letter-body">
        ${letter.text.split(/\n{2,}/).map((p) => html`<p>${p}</p>`)}
      </div>
      <a class="btn btn--ghost" href="#/">Back home</a>
    </article>`;
}

export function mount(root, { params }) {
  let revealed = false;
  const paint = () => render(root, template(getLetter(params.id), revealed));
  paint();

  const off = on(root, 'click', '[data-action="open"]', () => {
    revealed = true;
    markOpened(params.id);
    paint();
    qs('#letter-title', root)?.focus();
  });
  const offMinute = clock.onMinute((now) => {
    const letter = getLetter(params.id);
    const el = qs('[data-el="countdown"]', root);
    if (el && letter) el.textContent = countdownText(letter, now);
  });
  const offDay = clock.onDayChange(paint);

  return () => {
    off();
    offMinute();
    offDay();
  };
}
