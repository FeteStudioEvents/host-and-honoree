import { html, render } from '../core/dom.js';

export const title = 'Not found';

export function mount(root) {
  render(root, html`
    <section class="center stack fade-in mt-6">
      <h1>Lost the way?</h1>
      <p class="text-muted">This page wandered off before midnight.</p>
      <a class="btn" href="#/">Back home</a>
    </section>
  `);
}
