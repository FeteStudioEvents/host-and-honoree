import { clock } from '../core/clock.js';
import { html, on, qs, render } from '../core/dom.js';
import { store } from '../core/store.js';
import { toast } from '../core/toast.js';
import { CHECKIN_MOODS, FINALE, ROUNDS } from '../features/content.js';
import { clearGame, latestEntry, newGame } from '../features/game.js';
import { countdownText, formatDate, isOpenable } from '../features/letters.js';
import { isMidnightWindow, openCountdown } from '../features/midnight.js';
import { monthLabel, pendingCheckin, recordCheckin } from '../features/checkin.js';
import { burstArt, envelopeArt } from './art.js';

export const title = 'Home';

function primaryAction(game) {
  if (!game) {
    return store.get().archive.length
      ? html`<button class="btn btn--lux" type="button" data-action="start">Play again</button>`
      : html`<button class="btn btn--lux" type="button" data-action="start">Begin the evening</button>`;
  }
  if (game.round >= FINALE) {
    return html`<button class="btn btn--lux" type="button" data-action="resume">Return to your finale</button>`;
  }
  const round = ROUNDS[game.round - 1];
  return html`<button class="btn btn--lux" type="button" data-action="resume">Resume · Round ${game.round} of 6</button>
    <p class="text-sm text-muted">Paused at <span class="serif">${round.name}</span>. Everything is saved.</p>`;
}

function lettersBlock(letters, now) {
  if (!letters.length) return '';
  return html`
    <section class="stack" aria-labelledby="letters-title">
      <h2 class="eyebrow eyebrow--muted" id="letters-title">Letters to future you</h2>
      ${[...letters].sort((a, b) => a.revealOn.localeCompare(b.revealOn)).map((l) => {
        const ready = isOpenable(l);
        return html`
          <a class="envelope-card ${ready ? 'is-ready' : 'is-sealed'}" href="#/letter/${l.id}" data-letter="${l.id}"
             data-state="${ready ? 'ready' : 'sealed'}"
             aria-label="${ready ? `Your letter is ready to open. Sealed ${new Date(l.sealedAt).toLocaleDateString()}.`
               : `Sealed letter. Opens ${formatDate(l.revealOn)}. ${countdownText(l, now)}.`}">
            ${envelopeArt({ open: Boolean(l.openedAt) })}
            <span class="envelope-card__text">
              <span class="envelope-card__title serif">${ready ? (l.openedAt ? 'Your letter, opened' : 'Your letter is ready') : 'Sealed until ' + formatDate(l.revealOn)}</span>
              <span class="envelope-card__meta" data-el="countdown" data-letter-countdown="${l.id}">${ready ? (l.openedAt ? 'Read it again' : 'Open it now') : countdownText(l, now)}</span>
            </span>
          </a>`;
      })}
    </section>`;
}

function checkinBlock(pending) {
  if (!pending) return '';
  const { entry, month } = pending;
  return html`
    <section class="card checkin stack" aria-labelledby="checkin-title" data-el="checkin">
      <p class="eyebrow">${monthLabel(month)} check-in</p>
      <h2 class="checkin__title" id="checkin-title">How are your intentions feeling?</h2>
      ${entry.word ? html`<p class="text-muted">Your word for the year: <span class="serif text-gold">${entry.word}</span></p>` : ''}
      ${entry.intentions.filter((i) => i.text).map((intent, idx) => html`
        <fieldset class="checkin__row">
          <legend><span class="eyebrow eyebrow--muted">${intent.label}</span> <span class="serif">${intent.text}</span></legend>
          <div class="chips">
            ${CHECKIN_MOODS.map((m) => html`
              <label class="chip chip--radio">
                <input type="radio" name="checkin-${idx}" value="${m.id}" class="sr-only">
                <span>${m.label}</span>
              </label>`)}
          </div>
        </fieldset>`)}
      <div class="row-between">
        <button class="btn btn--ghost" type="button" data-action="checkin-later">Not this month</button>
        <button class="btn" type="button" data-action="checkin-save">Save check-in</button>
      </div>
    </section>`;
}

function intentionsBlock(entry) {
  if (!entry) return '';
  return html`
    <section class="card stack" aria-labelledby="intent-title">
      <p class="eyebrow" id="intent-title">${entry.inSeason ? `Your ${entry.newYear}` : 'Your fresh start'}</p>
      ${entry.word ? html`<p class="word-display serif">${entry.word}</p>` : ''}
      <ul class="intent-list">
        ${entry.intentions.filter((i) => i.text).map((i) => html`<li><span class="eyebrow eyebrow--muted">${i.label}</span><span>${i.text}</span></li>`)}
      </ul>
      <a class="link-btn" href="#/archive">Past years &amp; cards</a>
    </section>`;
}

function template(state, now) {
  const { game, letters } = state;
  return html`
    <div class="home stack-lg stack fade-in" data-el="home">
      <section class="hero" aria-labelledby="home-title">
        ${burstArt()}
        <p class="eyebrow">A New Year ritual for one</p>
        <h1 id="home-title" class="hero__title">Host &amp;<br>Honoree</h1>
        <p class="hero__lede serif">You’re the host and the guest of honor. Six short rounds, about twenty-five minutes, to close out the year and set your intentions.</p>
        <div class="hero__actions stack stack-sm">
          ${primaryAction(game)}
          ${game ? html`<button class="btn btn--ghost" type="button" data-action="restart" data-el="restart">Start over</button>` : ''}
        </div>
      </section>

      ${isMidnightWindow(now) ? html`
        <section class="card midnight-banner stack" aria-labelledby="mn-banner">
          <p class="eyebrow" id="mn-banner">It’s nearly midnight</p>
          <p class="serif text-lg">Midnight mode counts you into the new year, full screen, with a gentle chime.</p>
          <button class="btn" type="button" data-action="midnight">Midnight mode</button>
        </section>` : ''}

      ${checkinBlock(pendingCheckin(now))}
      ${lettersBlock(letters, now)}
      ${game ? '' : intentionsBlock(latestEntry())}

      <section class="stack" aria-labelledby="how-title">
        <h2 class="eyebrow eyebrow--muted" id="how-title">Tonight’s program</h2>
        <ol class="program">
          ${ROUNDS.map((r) => html`<li><span class="program__n">${r.n}</span><span class="serif">${r.name}</span></li>`)}
          <li><span class="program__n" aria-hidden="true">✦</span><span class="serif">Finale: midnight, and your share card</span></li>
        </ol>
        <p class="text-sm text-muted">Pour something sparkling (water, juice, tea, anything), find a comfortable seat, and take your time. You can pause whenever you like; the game saves as you go.</p>
      </section>
    </div>
  `;
}

export function mount(root, { navigate }) {
  const paint = () => render(root, template(store.get(), new Date()));
  paint();

  const actions = {
    start() {
      newGame();
      navigate('/play');
    },
    resume: () => navigate('/play'),
    restart(btn) {
      if (btn.dataset.armed !== 'true') {
        btn.dataset.armed = 'true';
        btn.textContent = 'Tap again to start over';
        setTimeout(() => {
          if (btn.isConnected) {
            btn.dataset.armed = 'false';
            btn.textContent = 'Start over';
          }
        }, 5000);
        return;
      }
      clearGame();
      newGame();
      navigate('/play');
    },
    midnight: () => openCountdown({ mode: 'midnight' }),
    'checkin-save'() {
      const pending = pendingCheckin();
      if (!pending) return;
      const moods = {};
      root.querySelectorAll('.checkin input:checked').forEach((input) => {
        moods[input.name.replace('checkin-', '')] = input.value;
      });
      recordCheckin(pending.entry.id, pending.month, { moods });
      toast('Check-in saved. See you next month.');
      paint();
    },
    'checkin-later'() {
      const pending = pendingCheckin();
      if (pending) recordCheckin(pending.entry.id, pending.month, { skipped: true });
      paint();
    },
  };
  const offClick = on(root, 'click', '[data-action]', (_, btn) => actions[btn.dataset.action]?.(btn));

  // Sealed letters count down each minute and open themselves when the date arrives.
  let midnightShown = isMidnightWindow();
  const offMinute = clock.onMinute((now) => {
    // At 11:00 PM on December 31st the Midnight mode banner appears by itself.
    if (isMidnightWindow(now) !== midnightShown) {
      midnightShown = isMidnightWindow(now);
      paint();
      return;
    }
    store.get().letters.forEach((l) => {
      const el = qs(`[data-letter-countdown="${l.id}"]`, root);
      if (el && !isOpenable(l, clock.today())) el.textContent = countdownText(l, now);
    });
  });
  const offDay = clock.onDayChange(paint);

  return () => {
    offClick();
    offMinute();
    offDay();
  };
}
