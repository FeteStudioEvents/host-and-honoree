import { html, on, qs, render } from '../core/dom.js';
import { onSuspend } from '../core/session.js';
import { toast } from '../core/toast.js';
import * as ambient from '../features/ambient.js';
import { FINALE, ROUNDS, SOUNDSCAPES } from '../features/content.js';
import { getGame, newGame, updateGame } from '../features/game.js';

export const title = 'Playing';

const ROUND_VIEWS = {
  1: () => import('./rounds/scene.js'),
  2: () => import('./rounds/reel.js'),
  3: () => import('./rounds/cards.js'),
  4: () => import('./rounds/letgo.js'),
  5: () => import('./rounds/word.js'),
  6: () => import('./rounds/letter.js'),
  7: () => import('./rounds/finale.js'),
};

function ribbon(round) {
  const steps = [...ROUNDS, { n: FINALE, name: 'Finale' }];
  const current = ROUNDS[round - 1];
  return html`
    <ol class="ribbon__steps">
      ${steps.map((s) => {
        const state = s.n < round ? 'done' : s.n === round ? 'current' : 'todo';
        const word = { done: 'complete', current: 'current', todo: 'not started yet' }[state];
        return html`<li class="ribbon__step ${s.n === FINALE ? 'ribbon__step--finale' : ''}" data-state="${state}"
                        ${state === 'current' ? html`aria-current="step"` : ''}>
          <span class="sr-only">${s.n === FINALE ? 'Finale' : `Round ${s.n}, ${s.name}`}: ${word}</span>
        </li>`;
      })}
    </ol>
    <p class="ribbon__label" aria-hidden="true">
      <span class="eyebrow">${current ? `Round ${round} of 6` : 'Finale'}</span>
    </p>`;
}

export function mount(root, { navigate }) {
  if (!getGame()) newGame();

  render(root, html`
    <div class="play">
      <nav class="ribbon" aria-label="Game progress" data-el="ribbon"></nav>
      <section class="round fade-in" data-el="round" aria-labelledby="round-title"></section>
      <p class="sr-only" aria-live="polite" data-el="announce"></p>
    </div>`);

  const ribbonEl = qs('[data-el="ribbon"]', root);
  const section = qs('[data-el="round"]', root);
  const announceEl = qs('[data-el="announce"]', root);
  const flushers = new Set();
  let cleanup = null;
  let navId = 0;

  const flushAll = () => flushers.forEach((fn) => fn());

  async function show(round, { focus = true } = {}) {
    const id = ++navId;
    flushAll();
    cleanup?.();
    cleanup = null;
    flushers.clear();
    const view = await ROUND_VIEWS[Math.min(round, FINALE)]();
    if (id !== navId) return;

    render(ribbonEl, ribbon(round));
    section.dataset.round = String(round);
    section.classList.remove('fade-in');
    void section.offsetWidth; // restart the fade for each round
    section.classList.add('fade-in');
    section.replaceChildren();
    cleanup = (await view.mount(section, ctx)) ?? null;
    document.title = `${ROUNDS[round - 1]?.name ?? 'Finale'} · Host & Honoree`;
    window.scrollTo(0, 0);
    if (focus) qs('#round-title', section)?.focus({ preventScroll: true });
  }

  const go = (round) => {
    flushAll();
    updateGame({ round });
    return show(round);
  };

  const ctx = {
    game: getGame,
    next: () => go(Math.min(getGame().round + 1, FINALE)),
    back: () => (getGame().round > 1 ? go(getGame().round - 1) : navigate('/')),
    onFlush: (fn) => flushers.add(fn),
    announce: (msg) => {
      announceEl.textContent = '';
      requestAnimationFrame(() => { announceEl.textContent = msg; });
    },
    navigate,
  };

  const offNav = on(root, 'click', '[data-nav]', (_, btn) => {
    if (btn.disabled) return;
    if (btn.dataset.nav === 'next') ctx.next();
    else ctx.back();
  });
  const offSuspend = onSuspend(flushAll);

  const game = getGame();
  show(game.round, { focus: false });

  // Audio can only start from a tap, so after a reload offer the soundscape rather than autoplay it.
  const sound = SOUNDSCAPES.find((s) => s.id === game.scene.sound && s.id !== 'none');
  if (game.round > 1 && sound && !ambient.isPlaying(sound.id)) {
    toast(`Pick up your soundscape? ${sound.label}`, { action: 'Play', duration: 8000, onAction: () => ambient.play(sound.id) });
  }

  return () => {
    navId++;
    flushAll();
    cleanup?.();
    offNav();
    offSuspend();
  };
}
