import { raw } from '../core/dom.js';

/** Decorative inline SVGs. All are aria-hidden: the surrounding text carries the meaning. */

const rays = (cx, cy, r1, rLong, rShort, count) => {
  let d = '';
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2 - Math.PI / 2;
    const r2 = i % 2 ? rShort : rLong;
    d += `M${(cx + r1 * Math.cos(a)).toFixed(1)} ${(cy + r1 * Math.sin(a)).toFixed(1)}L${(cx + r2 * Math.cos(a)).toFixed(1)} ${(cy + r2 * Math.sin(a)).toFixed(1)}`;
  }
  return d;
};

const BURST_D = rays(100, 100, 50, 92, 74, 20);

export const burstArt = () => raw(`
  <svg class="burst" viewBox="0 0 200 200" aria-hidden="true">
    <path class="burst__rays" d="${BURST_D}"/>
    <circle class="burst__face" cx="100" cy="100" r="38"/>
    <circle class="burst__twelve" cx="100" cy="72" r="3"/>
    <path class="burst__hand" d="M100 100V78"/>
    <circle class="burst__pin" cx="100" cy="100" r="4.5"/>
  </svg>`);

export const envelopeArt = ({ open = false } = {}) => raw(`
  <svg class="envelope ${open ? 'envelope--open' : ''}" viewBox="0 0 64 48" aria-hidden="true">
    <rect class="envelope__body" x="2" y="8" width="60" height="38" rx="5"/>
    <path class="envelope__flap" d="${open ? 'M4 10 32 2l28 8' : 'M4 10l28 20 28-20'}"/>
    ${open ? '' : '<circle class="envelope__seal" cx="32" cy="29" r="6.5"/><path class="envelope__seal-mark" d="M32 25.5v7M28.5 29h7"/>'}
  </svg>`);

export const candleArt = () => raw(`
  <svg class="candle-art" viewBox="0 0 120 180" aria-hidden="true">
    <ellipse class="candle-art__glow" cx="60" cy="52" rx="52" ry="52"/>
    <g class="candle-art__flame">
      <path class="candle-art__flame-outer" d="M60 18c-9 14-17 22-17 35a17 17 0 0 0 34 0c0-13-8-21-17-35z"/>
      <path class="candle-art__flame-inner" d="M60 36c-4 7-8 11-8 18a8 8 0 0 0 16 0c0-7-4-11-8-18z"/>
    </g>
    <path class="candle-art__wick" d="M60 64v10"/>
    <rect class="candle-art__wax" x="38" y="74" width="44" height="88" rx="8"/>
    <path class="candle-art__drip" d="M48 74v14a4 4 0 0 0 8 0v-6"/>
    <rect class="candle-art__dish" x="22" y="160" width="76" height="10" rx="5"/>
  </svg>`);

const CARD_D = rays(50, 50, 16, 34, 26, 16);
export const cardBackArt = () => raw(`
  <svg class="card-back__art" viewBox="0 0 100 100" aria-hidden="true">
    <path d="${CARD_D}"/>
    <circle cx="50" cy="50" r="10"/>
  </svg>`);

export const lockIcon = () => raw('<svg class="inline-icon" viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>');
