import { html, on, qs, render } from '../../core/dom.js';
import { toast } from '../../core/toast.js';
import * as ambient from '../../features/ambient.js';
import { archiveGame, clearGame, getGame } from '../../features/game.js';
import { formatDate, getLetter } from '../../features/letters.js';
import { isMidnightWindow, openCountdown } from '../../features/midnight.js';
import { canShareFiles, exportShareCard, shareCardBlob } from '../../features/share-card.js';
import { store } from '../../core/store.js';
import { roundHead } from './shared.js';

const entryFor = (game) => store.get().archive.find((e) => e.id === game.id);

function cardAlt(entry) {
  const parts = [`Share card: My year, my new year. ${entry.yearLabel}.`];
  if (entry.word) parts.push(`Word of the year: ${entry.word}.`);
  const ints = entry.intentions.filter((i) => i.text);
  if (ints.length) parts.push(`Intentions: ${ints.map((i) => `${i.label}, ${i.text}`).join('; ')}.`);
  if (entry.highlights.length) parts.push(`Highlights: ${entry.highlights.map((h) => `${h.month}, ${h.text}`).join('; ')}.`);
  return parts.join(' ');
}

function template(game, entry, midnight) {
  const letter = game.letterId ? getLetter(game.letterId) : null;
  return html`
    ${roundHead(0, 'To you, the guest of honor', 'You hosted, you showed up, and you closed the year with care. Now for the best part.')}

    <section class="card finale-midnight stack" aria-labelledby="fm-title">
      <p class="eyebrow" id="fm-title">${midnight ? 'It’s nearly midnight' : 'Your midnight'}</p>
      <p class="serif text-lg">${midnight
        ? 'Midnight mode counts you into the new year, full screen, with a gentle chime.'
        : 'Whatever the clock says, you can have a midnight of your own: ten seconds, a chime, and a toast.'}</p>
      <button class="btn btn--lux" type="button" data-action="${midnight ? 'midnight' : 'personal'}">
        ${midnight ? 'Midnight mode' : 'Count down my midnight'}
      </button>
    </section>

    <section class="share stack" aria-labelledby="share-title">
      <h3 class="eyebrow eyebrow--muted" id="share-title">Your share card</h3>
      <p class="text-sm text-muted">Story-sized, with your word, intentions and three highlights. Your letter and anything you let go are never on it.</p>
      <figure class="share__preview" data-el="preview">
        <img data-el="preview-img" alt="${cardAlt(entry)}" width="1080" height="1920">
      </figure>
      <button class="btn btn--lux" type="button" data-action="export" data-el="export">
        ${canShareFiles() ? 'Share my card' : 'Save my card'}
      </button>
    </section>

    <section class="card stack" aria-labelledby="sum-title">
      <p class="eyebrow" id="sum-title">Your word</p>
      <p class="word-display serif">${entry.word || '—'}</p>
      <ul class="intent-list">
        ${entry.intentions.filter((i) => i.text).map((i) => html`<li><span class="eyebrow eyebrow--muted">${i.label}</span><span>${i.text}</span></li>`)}
      </ul>
      ${letter ? html`<p class="text-sm text-muted">Your letter is sealed until ${formatDate(letter.revealOn)}.</p>` : ''}
      <p class="text-sm text-muted">From next month, a gentle check-in on these will be waiting when you open the app.</p>
    </section>

    <div class="round__nav">
      <button class="btn btn--ghost" type="button" data-nav="back">Back</button>
      <button class="btn btn--lux" type="button" data-action="finish">Finish the night</button>
    </div>`;
}

export async function mount(section, ctx) {
  const game = getGame();
  archiveGame(game);
  const entry = entryFor(game);
  render(section, template(game, entry, isMidnightWindow()));

  let previewUrl = null;
  const img = qs('[data-el="preview-img"]', section);
  shareCardBlob(entry).then((blob) => {
    if (!section.isConnected) return;
    previewUrl = URL.createObjectURL(blob);
    img.src = previewUrl;
    qs('[data-el="preview"]', section).dataset.ready = '';
  }).catch(() => {});

  const actions = {
    midnight: () => openCountdown({ mode: 'midnight' }),
    personal: () => openCountdown({ mode: 'personal', newYear: game.inSeason ? game.newYear : null }),
    async export(btn) {
      btn.disabled = true;
      try {
        const result = await exportShareCard(entryFor(getGame()) ?? entry);
        if (result === 'downloaded') toast('Card saved to your downloads.');
        if (result === 'shared') toast('Shared. Cheers to your year.');
      } catch {
        toast('That didn’t work. Please try again.');
      } finally {
        btn.disabled = false;
      }
    },
    finish() {
      ambient.fadeOutAll(4);
      clearGame();
      toast('Happy new year. Your card and intentions are in Past years.');
      ctx.navigate('/');
    },
  };
  const off = on(section, 'click', '[data-action]', (_, btn) => actions[btn.dataset.action]?.(btn));

  return () => {
    off();
    if (previewUrl) URL.revokeObjectURL(previewUrl);
  };
}
