import { html, on, qs, render } from '../../core/dom.js';
import { store } from '../../core/store.js';
import * as ambient from '../../features/ambient.js';
import { DRESS_CODES, SOUNDSCAPES } from '../../features/content.js';
import { getGame, updateGame } from '../../features/game.js';
import { candleArt } from '../art.js';
import { roundHead, roundNav } from './shared.js';

const ICONS = {
  cabin: '<path d="M12 3c-2 4-6 6-6 10a6 6 0 0 0 12 0c0-4-4-6-6-10z"/><path d="M12 13c-1 2-2.5 2.8-2.5 4.5a2.5 2.5 0 0 0 5 0c0-1.7-1.5-2.5-2.5-4.5z"/>',
  snow: '<path d="M12 3v18M4.2 7.5l15.6 9M4.2 16.5l15.6-9"/><path d="M9.5 4.5 12 6l2.5-1.5M9.5 19.5 12 18l2.5 1.5"/>',
  rain: '<path d="M7 4.5 5.5 9M12.5 3 11 7.5M18 4.5 16.5 9M9.5 12 8 16.5M15 12l-1.5 4.5M12 18.5 11 21"/>',
  brown: '<path d="M3 9c3-3 6 3 9 0s6-3 9 0M3 15c3-3 6 3 9 0s6-3 9 0"/>',
  none: '<path d="M12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16zM12 8v4l2.5 2.5"/>',
};

function template(game) {
  const { scene } = game;
  return html`
    ${roundHead(1, 'Set the scene', 'Dim a light. Pour yourself something sparkling: water, juice, tea, anything. Then make the evening yours.')}

    <fieldset class="choice-group">
      <legend class="eyebrow eyebrow--muted">Choose a soundscape</legend>
      <div class="option-grid option-grid--sound">
        ${SOUNDSCAPES.map((s) => html`
          <label class="option option--sound">
            <input class="option__input" type="radio" name="sound" value="${s.id}" ${scene.sound === s.id ? 'checked' : ''}>
            <span class="option__body">
              <svg viewBox="0 0 24 24" class="option__icon" aria-hidden="true">${{ __raw: ICONS[s.id] }}</svg>
              <span class="option__name serif">${s.label}</span>
              <span class="option__note">${s.note}</span>
            </span>
          </label>`)}
      </div>
      <label class="volume-row" data-el="volume-row" ${scene.sound && scene.sound !== 'none' ? '' : 'hidden'}>
        <span class="text-sm text-muted">Volume</span>
        <input type="range" min="0" max="1" step="0.01" value="${store.get().ambient.volume}" data-el="volume">
      </label>
      <p class="text-xs text-muted">On some phones, the silent switch also mutes sound here.</p>
    </fieldset>

    <fieldset class="choice-group">
      <legend class="eyebrow eyebrow--muted">Draw a dress code</legend>
      <p class="text-sm text-muted">Just for fun. Nobody’s checking, except you.</p>
      <div class="option-grid">
        ${DRESS_CODES.map((d) => html`
          <label class="option option--dress">
            <input class="option__input" type="radio" name="dress" value="${d.id}" ${scene.dress === d.id ? 'checked' : ''}>
            <span class="option__body">
              <span class="option__name serif">${d.label}</span>
              <span class="option__note">${d.note}</span>
            </span>
          </label>`)}
      </div>
    </fieldset>

    <section class="candle-stage" aria-labelledby="candle-title">
      <h3 class="eyebrow eyebrow--muted" id="candle-title">Light your candle</h3>
      <button class="candle" type="button" data-el="candle" aria-pressed="${scene.candle}"
              aria-label="${scene.candle ? 'Your candle is lit' : 'Light the candle'}">
        ${candleArt()}
      </button>
      <p class="candle-stage__caption serif" data-el="candle-caption">${scene.candle ? 'Your candle is lit. The evening is yours.' : 'Tap the candle to begin.'}</p>
    </section>

    ${roundNav({ back: true, next: 'Begin the reel', nextDisabled: !scene.candle, hint: scene.candle ? '' : 'Light the candle to continue.' })}
  `;
}

export function mount(section, ctx) {
  render(section, template(getGame()));
  const setScene = (patch) => updateGame((g) => ({ scene: { ...g.scene, ...patch } }));

  const offChange = on(section, 'change', 'input[type="radio"]', (_, input) => {
    if (input.name === 'sound') {
      ambient.SOUND_LIST.forEach((s) => s.id !== input.value && ambient.stop(s.id));
      if (input.value !== 'none') ambient.play(input.value);
      setScene({ sound: input.value });
      qs('[data-el="volume-row"]', section).hidden = input.value === 'none';
      store.set(({ ambient: a }) => ({ ambient: { ...a, sound: input.value } }));
    } else {
      setScene({ dress: input.value });
      const pick = DRESS_CODES.find((d) => d.id === input.value);
      ctx.announce(`Dress code: ${pick.label}. ${pick.note}`);
    }
  });

  const volume = qs('[data-el="volume"]', section);
  ambient.setVolume(Number(volume.value));
  volume.addEventListener('input', () => ambient.setVolume(Number(volume.value)));
  volume.addEventListener('change', () => store.set(({ ambient: a }) => ({ ambient: { ...a, volume: Number(volume.value) } })));

  const candle = qs('[data-el="candle"]', section);
  candle.addEventListener('click', () => {
    if (getGame().scene.candle) return;
    setScene({ candle: true });
    candle.setAttribute('aria-pressed', 'true');
    candle.setAttribute('aria-label', 'Your candle is lit');
    qs('[data-el="candle-caption"]', section).textContent = 'Your candle is lit. The evening is yours.';
    const next = qs('[data-nav="next"]', section);
    next.disabled = false;
    next.removeAttribute('aria-describedby');
    qs('[data-el="nav-hint"]', section)?.remove();
    ctx.announce('Candle lit. You can begin the highlight reel.');
  });

  return () => {
    offChange();
  };
}
