import { html, on, qs, render } from '../../core/dom.js';
import { store } from '../../core/store.js';
import { chipsForMonth } from '../../features/content.js';
import { getGame, highlightIndexes, MONTHS, monthEntryText, updateGame } from '../../features/game.js';
import { reducedMotion } from '../../features/motion.js';
import { debounced, roundHead, roundNav } from './shared.js';

const FIRST_THOUGHT_S = 3;
const RECAP = 12;

const visited = (e) => Boolean(monthEntryText(e)) || e.skipped;
const short = (m) => MONTHS[m].slice(0, 3);

function stripTemplate(game) {
  return game.months.map((e, i) => {
    const text = monthEntryText(e);
    const state = i === game.monthAt ? 'current' : text ? 'filled' : e.skipped ? 'skipped' : 'todo';
    const label = `${MONTHS[e.m]}: ${text || (e.skipped ? 'skipped' : 'not yet')}`;
    return html`<button class="month-tile" type="button" data-month="${i}" data-state="${state}"
                        aria-label="${label}" ${i === game.monthAt ? html`aria-current="true"` : ''}>
      <span aria-hidden="true">${short(e.m)}</span>
    </button>`;
  });
}

function monthTemplate(game, timerOn) {
  const i = game.monthAt;
  const entry = game.months[i];
  const name = MONTHS[entry.m];
  return html`
    <article class="month-card" data-month-card="${i}" aria-labelledby="month-title">
      <div class="month-card__top">
        <h3 class="month-card__name serif" id="month-title" tabindex="-1">${name} <span class="month-card__year">${entry.y}</span></h3>
        <div class="ft" data-el="ft" ${timerOn ? '' : 'hidden'}>
          <svg viewBox="0 0 40 40" aria-hidden="true"><circle class="ft__track" cx="20" cy="20" r="17"/><circle class="ft__fill" cx="20" cy="20" r="17"/></svg>
          <span class="ft__n" data-el="ft-n" aria-hidden="true">${FIRST_THOUGHT_S}</span>
          <span class="sr-only" data-el="ft-sr">First-thought timer running</span>
        </div>
      </div>
      <p class="text-sm text-muted">What comes to mind first?</p>
      <div class="chips" role="group" aria-label="Memories for ${name}">
        ${chipsForMonth(i).map((c) => html`<button class="chip" type="button" data-chip="${c}" aria-pressed="${entry.chip === c}">${c}</button>`)}
      </div>
      <form class="month-form" data-el="month-form">
        <label class="text-sm" for="month-text">Or a few words of your own</label>
        <div class="row">
          <input class="input" id="month-text" type="text" maxlength="60" autocomplete="off" enterkeyhint="next"
                 value="${entry.text}" placeholder="e.g. Learned to bake bread">
          <button class="btn" type="submit">Next</button>
        </div>
      </form>
      <button class="link-btn" type="button" data-action="skip">Skip ${name}</button>
    </article>`;
}

function recapTemplate(game) {
  const starred = new Set(highlightIndexes(game));
  return html`
    <div class="recap">
      <h3 class="serif recap__title" id="month-title" tabindex="-1">Your year in twelve</h3>
      <p class="text-sm text-muted">Star up to three highlights for your share card. Tap any month above to change it.</p>
      <ul class="recap__list">
        ${game.months.map((e, i) => {
          const text = monthEntryText(e);
          if (!text) {
            return html`<li class="recap__item recap__item--empty">
              <span class="recap__month eyebrow eyebrow--muted">${short(e.m)}</span>
              <button class="link-btn" type="button" data-month="${i}">Add ${MONTHS[e.m]}</button>
            </li>`;
          }
          return html`<li class="recap__item">
            <button class="star" type="button" data-star="${i}" aria-pressed="${starred.has(i)}"
                    aria-label="Star ${MONTHS[e.m]}: ${text}">
              <span class="recap__month eyebrow">${short(e.m)}</span>
              <span class="recap__text serif">${text}</span>
              <svg class="star__icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3.5 2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8L3.5 9.7l5.9-.9z"/></svg>
            </button>
          </li>`;
        })}
      </ul>
      <p class="text-sm text-muted" data-el="star-count" aria-live="polite">${starred.size} of 3 starred</p>
    </div>`;
}

function template(game, timerOn) {
  return html`
    ${roundHead(2, 'Highlight reel', 'Twelve months, quick-fire. Tap a memory or type a few words. First thoughts are the good ones.')}
    <div class="month-strip" role="group" aria-label="Months of the year" data-el="strip">${stripTemplate(game)}</div>
    <div class="reel-stage" data-el="stage"></div>
    <label class="switch">
      <input type="checkbox" role="switch" data-el="ft-toggle" ${timerOn ? 'checked' : ''}>
      <span class="switch__track" aria-hidden="true"></span>
      <span class="switch__text">First-thought timer <span class="text-xs text-muted">Moves on after ${FIRST_THOUGHT_S} seconds if nothing is chosen</span></span>
    </label>
    ${roundNav({ next: game.monthAt >= RECAP ? 'Continue' : 'See my year' })}`;
}

export function mount(section, ctx) {
  const timerOn = () => store.get().settings.firstThought;
  render(section, template(getGame(), timerOn()));

  const strip = qs('[data-el="strip"]', section);
  const stage = qs('[data-el="stage"]', section);
  const nextBtn = qs('[data-nav="next"]', section);
  let tick = null;
  let advanceTimer = null;

  const setMonth = (i, patch) => updateGame((g) => ({
    months: g.months.map((e, k) => (k === i ? { ...e, ...patch } : e)),
  }));

  const saveText = debounced((i, text) => setMonth(i, { text, skipped: false }));
  ctx.onFlush(() => saveText.flush());

  function stopTimer() {
    clearInterval(tick);
    tick = null;
    const ft = qs('[data-el="ft"]', stage);
    if (ft) {
      delete ft.dataset.running;
      ft.dataset.paused = '';
      qs('[data-el="ft-sr"]', ft).textContent = 'First-thought timer paused';
    }
  }

  function startTimer() {
    stopTimer();
    const ft = qs('[data-el="ft"]', stage);
    if (!ft || !timerOn()) return;
    let left = FIRST_THOUGHT_S;
    delete ft.dataset.paused;
    void ft.offsetWidth;
    ft.dataset.running = '';
    qs('[data-el="ft-n"]', ft).textContent = String(left);
    qs('[data-el="ft-sr"]', ft).textContent = 'First-thought timer running';
    tick = setInterval(() => {
      left -= 1;
      qs('[data-el="ft-n"]', ft).textContent = String(Math.max(left, 0));
      if (left <= 0) {
        stopTimer();
        const i = getGame().monthAt;
        if (!monthEntryText(getGame().months[i])) setMonth(i, { skipped: true });
        ctx.announce(`${MONTHS[getGame().months[i].m]} skipped.`);
        advance(i);
      }
    }, 1000);
  }

  function paintStage({ focus = true } = {}) {
    clearTimeout(advanceTimer);
    stopTimer();
    const game = getGame();
    render(strip, stripTemplate(game));
    render(stage, game.monthAt >= RECAP ? recapTemplate(game) : monthTemplate(game, timerOn()));
    nextBtn.textContent = game.monthAt >= RECAP ? 'Continue' : 'See my year';
    if (focus) qs('#month-title', stage)?.focus({ preventScroll: true });
    // The timer only runs on a fresh month; revisiting one you already answered is never rushed.
    if (game.monthAt < RECAP && !visited(game.months[game.monthAt])) startTimer();
  }

  function goTo(i) {
    saveText.flush();
    updateGame({ monthAt: i });
    paintStage();
    const strip = qs(`[data-month="${i}"]`, section);
    strip?.scrollIntoView?.({ block: 'nearest', inline: 'center', behavior: reducedMotion() ? 'auto' : 'smooth' });
  }

  /** Moves to the next month not yet answered or skipped, or to the recap. */
  function advance(from) {
    saveText.flush();
    const { months } = getGame();
    let next = RECAP;
    for (let k = from + 1; k < months.length; k++) {
      if (!visited(months[k])) { next = k; break; }
    }
    goTo(next);
  }

  // Any touch, key or typing means the player is thinking: the timer steps aside.
  const pause = () => tick && stopTimer();
  stage.addEventListener('pointerdown', pause);
  stage.addEventListener('keydown', pause);
  stage.addEventListener('focusin', (e) => {
    if (e.target.matches('input')) pause();
  });

  const offChip = on(stage, 'click', '[data-chip]', (_, chip) => {
    const i = getGame().monthAt;
    const was = getGame().months[i].chip;
    const value = was === chip.dataset.chip ? null : chip.dataset.chip;
    setMonth(i, { chip: value, skipped: false });
    stage.querySelectorAll('[data-chip]').forEach((c) => c.setAttribute('aria-pressed', String(c.dataset.chip === value)));
    if (value) {
      ctx.announce(`${MONTHS[getGame().months[i].m]}: ${value}`);
      clearTimeout(advanceTimer);
      advanceTimer = setTimeout(() => advance(i), reducedMotion() ? 120 : 380);
    }
  });

  const offInput = on(stage, 'input', '#month-text', (_, input) => saveText(getGame().monthAt, input.value));
  const offSubmit = on(stage, 'submit', '[data-el="month-form"]', (e) => {
    e.preventDefault();
    const i = getGame().monthAt;
    saveText.flush();
    advance(i);
  });
  const offSkip = on(stage, 'click', '[data-action="skip"]', () => {
    const i = getGame().monthAt;
    if (!monthEntryText(getGame().months[i])) setMonth(i, { skipped: true });
    advance(i);
  });

  const offStrip = on(section, 'click', '[data-month]', (_, btn) => goTo(Number(btn.dataset.month)));

  const offStar = on(stage, 'click', '[data-star]', (_, btn) => {
    const i = Number(btn.dataset.star);
    const current = highlightIndexes(getGame());
    let stars;
    if (current.includes(i)) stars = current.filter((k) => k !== i);
    else if (current.length >= 3) {
      ctx.announce('You can star three. Unstar one first.');
      qs('[data-el="star-count"]', stage).textContent = 'Three is the limit. Unstar one to swap.';
      return;
    } else stars = [...current, i];
    updateGame({ stars });
    stage.querySelectorAll('[data-star]').forEach((b) => b.setAttribute('aria-pressed', String(stars.includes(Number(b.dataset.star)))));
    qs('[data-el="star-count"]', stage).textContent = `${stars.length} of 3 starred`;
  });

  const toggle = qs('[data-el="ft-toggle"]', section);
  toggle.addEventListener('change', () => {
    store.set(({ settings }) => ({ settings: { ...settings, firstThought: toggle.checked } }));
    const ft = qs('[data-el="ft"]', stage);
    if (ft) ft.hidden = !toggle.checked;
    if (toggle.checked && getGame().monthAt < RECAP && !visited(getGame().months[getGame().monthAt])) startTimer();
    else stopTimer();
  });

  // "See my year" jumps to the recap; at the recap it continues to round 3.
  nextBtn.addEventListener('click', (e) => {
    if (getGame().monthAt < RECAP) {
      e.stopPropagation();
      goTo(RECAP);
    }
  }, { capture: true });

  paintStage({ focus: false });

  return () => {
    clearTimeout(advanceTimer);
    stopTimer();
    saveText.flush();
    offChip();
    offInput();
    offSubmit();
    offSkip();
    offStrip();
    offStar();
  };
}
