import { html, on, qs, render } from '../../core/dom.js';
import { CATEGORIES, cardById } from '../../features/content.js';
import { flipCard, getGame, redrawCard, updateGame } from '../../features/game.js';
import { reducedMotion } from '../../features/motion.js';
import { cardBackArt } from '../art.js';
import { debounced, roundHead, roundNav } from './shared.js';

const FLIP_MS = 700;

function cardLabel(slot, card) {
  if (!card.flipped) return `Card ${slot + 1} of 3, face down. Turn it over.`;
  const c = cardById(card.id);
  return `Card ${slot + 1} of 3, ${CATEGORIES[c.cat].label}: ${c.text}`;
}

function slotTemplate(game, slot) {
  const card = game.cards[slot];
  const c = cardById(card.id);
  const cat = CATEGORIES[c.cat];
  return html`
    <div class="draw-slot" data-slot="${slot}">
      <button class="flip ${card.flipped ? 'is-flipped' : ''}" type="button" data-flip="${slot}"
              aria-label="${cardLabel(slot, card)}" data-cat="${c.cat}">
        <span class="flip__inner">
          <span class="flip__face flip__back">${cardBackArt()}<span class="flip__hint">Tap to turn over</span></span>
          <span class="flip__face flip__front" data-color="${cat.color}">
            <span class="flip__cat eyebrow">${cat.label}</span>
            <span class="flip__text serif">${card.flipped ? c.text : ''}</span>
          </span>
        </span>
      </button>
      <div class="draw-slot__after" ${card.flipped ? '' : 'hidden'}>
        <label class="sr-only" for="answer-${slot}">Your thoughts on card ${slot + 1}</label>
        <textarea class="input input--area" id="answer-${slot}" rows="3" data-answer="${slot}"
                  placeholder="A few words, if you like. Saved only on this device.">${game.answers[card.id] ?? ''}</textarea>
        <button class="link-btn" type="button" data-redraw="${slot}" ${card.redrawn ? 'disabled' : ''}>
          ${card.redrawn ? 'Redrawn' : 'Redraw this card (once)'}
        </button>
      </div>
    </div>`;
}

export function mount(section, ctx) {
  const game = getGame();
  render(section, html`
    ${roundHead(3, 'The card draw', 'Three cards from a deck of sixty: proud, learned, surprised, grateful and let go. Turn each one over. Not the right question? Each card can be redrawn once.')}
    <div class="deck" data-el="deck">
      ${game.cards.map((_, slot) => slotTemplate(game, slot))}
    </div>
    ${roundNav({ next: 'Continue' })}
  `);
  const deck = qs('[data-el="deck"]', section);

  const saveAnswer = debounced((cardId, text) => updateGame((g) => ({ answers: { ...g.answers, [cardId]: text } })));
  ctx.onFlush(() => saveAnswer.flush());

  function repaint(slot, { focusText = false } = {}) {
    const old = qs(`[data-slot="${slot}"]`, deck);
    const tmp = document.createElement('div');
    render(tmp, slotTemplate(getGame(), slot));
    old.replaceWith(tmp.firstElementChild);
    if (focusText) qs(`[data-answer="${slot}"]`, deck)?.focus({ preventScroll: true });
  }

  const offFlip = on(deck, 'click', '[data-flip]', (_, btn) => {
    const slot = Number(btn.dataset.flip);
    const card = getGame().cards[slot];
    if (card.flipped) {
      qs(`[data-answer="${slot}"]`, deck)?.focus();
      return;
    }
    flipCard(slot);
    const c = cardById(card.id);
    qs('.flip__text', btn).textContent = c.text;
    btn.classList.add('is-flipped');
    btn.setAttribute('aria-label', cardLabel(slot, getGame().cards[slot]));
    ctx.announce(`${CATEGORIES[c.cat].label}. ${c.text}`);
    const after = qs(`[data-slot="${slot}"] .draw-slot__after`, deck);
    if (reducedMotion()) after.hidden = false;
    else setTimeout(() => { after.hidden = false; }, FLIP_MS * 0.6);
  });

  const offRedraw = on(deck, 'click', '[data-redraw]', (_, btn) => {
    const slot = Number(btn.dataset.redraw);
    if (getGame().cards[slot].redrawn) return;
    saveAnswer.flush();
    const flipBtn = qs(`[data-flip="${slot}"]`, deck);
    const swap = () => {
      redrawCard(slot);
      repaint(slot);
      const fresh = qs(`[data-flip="${slot}"]`, deck);
      const c = cardById(getGame().cards[slot].id);
      ctx.announce(`New card. ${CATEGORIES[c.cat].label}. ${c.text}`);
      fresh.focus({ preventScroll: true });
      if (!reducedMotion()) {
        // Draw the new card face down, then turn it over.
        fresh.classList.remove('is-flipped');
        void fresh.offsetWidth;
        fresh.classList.add('is-flipped');
      }
    };
    if (reducedMotion()) swap();
    else {
      flipBtn.classList.remove('is-flipped');
      setTimeout(swap, FLIP_MS * 0.6);
    }
  });

  const offAnswer = on(deck, 'input', '[data-answer]', (_, ta) => {
    const card = getGame().cards[Number(ta.dataset.answer)];
    saveAnswer(card.id, ta.value);
  });

  return () => {
    saveAnswer.flush();
    offFlip();
    offRedraw();
    offAnswer();
  };
}
