import { html, on, qs, render } from '../../core/dom.js';
import { getGame, updateGame } from '../../features/game.js';
import { formatDate, getLetter, sealLetter, tomorrowKey } from '../../features/letters.js';
import { settle } from '../../features/motion.js';
import { envelopeArt } from '../art.js';
import { debounced, roundHead, roundNav } from './shared.js';

function sealedTemplate(letter) {
  return html`
    <div class="sealed stack" data-el="sealed">
      <div class="sealed__art">${envelopeArt()}</div>
      <p class="serif text-lg">Sealed. It opens on <strong>${formatDate(letter.revealOn)}</strong>.</p>
      <p class="text-sm text-muted">It waits on this device as a sealed envelope on your home screen. Until then, not even you can peek.</p>
    </div>`;
}

function writeTemplate(game) {
  return html`
    <form class="letter-form stack" data-el="letter-form">
      <label class="serif text-lg" for="letter-text">Dear future me,</label>
      <textarea class="input input--area letter-paper" id="letter-text" rows="10" data-el="letter-text"
                placeholder="What do you hope you’ll remember? What are you rooting for? What would you like to hear on a hard day?">${game.letterDraft}</textarea>
      <div class="field">
        <label class="text-sm" for="reveal-date">Open it on</label>
        <input class="input input--date" id="reveal-date" type="date" min="${tomorrowKey()}" value="${game.revealOn}"
               data-el="reveal" aria-describedby="reveal-help">
        <p class="text-xs text-muted" id="reveal-help">Stored only on this device, sealed until this date.</p>
      </div>
      <div class="row-between">
        <button class="link-btn" type="button" data-action="skip-letter">Skip the letter</button>
        <button class="btn btn--lux" type="submit" data-el="seal" ${game.letterDraft.trim() ? '' : 'disabled'}>Seal the letter</button>
      </div>
    </form>`;
}

export function mount(section, ctx) {
  const paint = () => {
    const game = getGame();
    const letter = game.letterId ? getLetter(game.letterId) : null;
    render(section, html`
      ${roundHead(6, 'Letter to future you', 'Write to the person who will open this. It’s sealed on this device until the date you choose.')}
      <div data-el="body">${letter ? sealedTemplate(letter) : writeTemplate(game)}</div>
      ${roundNav({ next: 'On to the finale' })}
    `);
  };
  paint();

  const saveDraft = debounced((text) => updateGame({ letterDraft: text }));
  ctx.onFlush(() => saveDraft.flush());

  const offInput = on(section, 'input', '[data-el="letter-text"]', (_, ta) => {
    saveDraft(ta.value);
    qs('[data-el="seal"]', section).disabled = !ta.value.trim();
  });

  const offDate = on(section, 'change', '[data-el="reveal"]', (_, input) => {
    const min = tomorrowKey();
    const value = input.value && input.value >= min ? input.value : getGame().revealOn;
    input.value = value;
    updateGame({ revealOn: value });
  });

  const offSubmit = on(section, 'submit', '[data-el="letter-form"]', async (e) => {
    e.preventDefault();
    const text = qs('[data-el="letter-text"]', section).value.trim();
    if (!text) return;
    const dateInput = qs('[data-el="reveal"]', section);
    const revealOn = dateInput.value >= tomorrowKey() ? dateInput.value : getGame().revealOn;
    saveDraft.flush();
    const letter = sealLetter({ text, revealOn, gameId: getGame().id });
    updateGame({ letterId: letter.id, letterDraft: '', revealOn, letterSkipped: false });
    const form = qs('[data-el="letter-form"]', section);
    form.classList.add('is-folding');
    await settle(650);
    paint();
    qs('[data-el="sealed"]', section)?.classList.add('is-new');
    qs('#round-title', section)?.focus({ preventScroll: true });
    ctx.announce(`Letter sealed until ${formatDate(revealOn)}.`);
  });

  const offSkip = on(section, 'click', '[data-action="skip-letter"]', () => {
    saveDraft.flush();
    updateGame({ letterSkipped: true });
    ctx.next();
  });

  return () => {
    saveDraft.flush();
    offInput();
    offDate();
    offSubmit();
    offSkip();
  };
}
