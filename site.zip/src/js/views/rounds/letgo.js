import { html, on, qs, render } from '../../core/dom.js';
import { settle } from '../../features/motion.js';
import { lockIcon } from '../art.js';
import { roundHead, roundNav } from './shared.js';

/**
 * Clear the slate. Everything typed here lives only in the `papers` array below and
 * in the DOM. It is never written to the store, localStorage or anywhere else,
 * and it is gone when released, when the round changes, or when the app closes.
 */

const RELEASE_MS = 1600;

export function mount(section) {
  let papers = [];
  let releasing = false;

  render(section, html`
    ${roundHead(4, 'Clear the slate', 'Write down what you’re leaving in this year: a worry, a habit, an old grudge, a “should”. Then burn it or float it away.')}
    <p class="privacy-note" role="note" data-el="letgo-note">
      ${lockIcon()}
      <span><strong>Nothing in this round is saved</strong>, not even for a moment. It disappears when you release it, or if you leave this screen.</span>
    </p>
    <form class="letgo-form" data-el="letgo-form" autocomplete="off">
      <label for="letgo-input" class="text-sm">Something to leave behind</label>
      <div class="row">
        <input class="input" id="letgo-input" type="text" maxlength="120" autocomplete="off" enterkeyhint="done"
               placeholder="e.g. Saying yes when I mean no">
        <button class="btn" type="submit">Add</button>
      </div>
    </form>
    <ul class="papers" data-el="papers" aria-label="Things to let go"></ul>
    <div class="release-row">
      <button class="btn btn--burn" type="button" data-release="burn" disabled>
        <svg class="inline-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3c-2 4-6 6-6 10a6 6 0 0 0 12 0c0-4-4-6-6-10z"/></svg> Burn it
      </button>
      <button class="btn btn--float" type="button" data-release="float" disabled>
        <svg class="inline-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20V6M6.5 11.5 12 6l5.5 5.5"/></svg> Float it away
      </button>
    </div>
    <p class="letgo-done serif" data-el="letgo-done" aria-live="polite"></p>
    ${roundNav({ next: 'Continue' })}
  `);

  const list = qs('[data-el="papers"]', section);
  const input = qs('#letgo-input', section);
  const done = qs('[data-el="letgo-done"]', section);
  const releaseBtns = section.querySelectorAll('[data-release]');

  const sync = () => releaseBtns.forEach((b) => { b.disabled = releasing || (papers.length === 0 && !input.value.trim()); });
  input.addEventListener('input', sync);

  function paint() {
    render(list, papers.map((text, i) => html`
      <li class="paper">
        <span class="paper__text">${text}</span>
        <button class="paper__remove" type="button" data-remove="${i}" aria-label="Remove: ${text}">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>
        </button>
      </li>`));
    sync();
  }

  const offSubmit = on(section, 'submit', '[data-el="letgo-form"]', (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    papers = [...papers, text];
    input.value = '';
    done.textContent = '';
    paint();
    input.focus();
  });

  const offRemove = on(list, 'click', '[data-remove]', (_, btn) => {
    papers = papers.filter((_, i) => i !== Number(btn.dataset.remove));
    paint();
    input.focus();
  });

  const offRelease = on(section, 'click', '[data-release]', async (_, btn) => {
    // Anything still in the box goes too.
    const pending = input.value.trim();
    if (releasing || (!papers.length && !pending)) return;
    if (pending) {
      papers = [...papers, pending];
      input.value = '';
      paint();
    }
    releasing = true;
    sync();
    const mode = btn.dataset.release;
    list.dataset.release = mode;
    list.querySelectorAll('.paper').forEach((p, i) => {
      p.style.setProperty('--i', String(i));
      p.classList.add(mode === 'burn' ? 'is-burning' : 'is-floating');
    });
    await settle(RELEASE_MS + papers.length * 120);
    papers = [];
    delete list.dataset.release;
    releasing = false;
    paint();
    done.textContent = mode === 'burn' ? 'Burned away. Lighter already.' : 'Floated off into the night. Lighter already.';
  });

  return () => {
    papers = [];
    offSubmit();
    offRemove();
    offRelease();
  };
}
