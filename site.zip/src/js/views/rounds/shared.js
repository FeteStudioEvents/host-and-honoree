import { html } from '../../core/dom.js';

/** Common round header: focusable heading (focus lands here on each new round) and intro. The ribbon above carries "Round n of 6". */
export const roundHead = (n, title, intro) => html`
  <header class="round__head">
    <h2 class="round__title" id="round-title" tabindex="-1">${title}</h2>
    ${intro ? html`<p class="round__intro">${intro}</p>` : ''}
  </header>`;

/** Back / Continue bar at the foot of every round. */
export const roundNav = ({ back = true, next = 'Continue', nextDisabled = false, hint = '' } = {}) => html`
  <div class="round__nav">
    ${back ? html`<button class="btn btn--ghost" type="button" data-nav="back">Back</button>` : html`<span></span>`}
    <button class="btn btn--lux" type="button" data-nav="next" ${nextDisabled ? 'disabled' : ''}
            ${hint ? html`aria-describedby="nav-hint"` : ''}>${next}</button>
  </div>
  ${hint ? html`<p class="round__hint text-sm text-muted" id="nav-hint" data-el="nav-hint">${hint}</p>` : ''}`;

/** Debounced save for text fields; `flush()` writes immediately (used on round change and app hide). */
export function debounced(fn, ms = 400) {
  let timer = null;
  let pending = null;
  const run = () => {
    clearTimeout(timer);
    timer = null;
    if (pending) {
      const args = pending;
      pending = null;
      fn(...args);
    }
  };
  const call = (...args) => {
    pending = args;
    clearTimeout(timer);
    timer = setTimeout(run, ms);
  };
  call.flush = run;
  return call;
}
