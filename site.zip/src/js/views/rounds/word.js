import { html, on, qs, render } from '../../core/dom.js';
import { INTENTION_DEFAULTS, WORDS } from '../../features/content.js';
import { getGame, updateGame } from '../../features/game.js';
import { reducedMotion } from '../../features/motion.js';
import { debounced, roundHead, roundNav } from './shared.js';

const SPIN_FRAMES = 18;

function template(game) {
  return html`
    ${roundHead(5, 'Word of the year', 'One word to carry into the new year. Spin the deck of eighty, or bring your own.')}
    <section class="word-stage" aria-labelledby="word-label">
      <p class="eyebrow eyebrow--muted" id="word-label">Your word</p>
      <div class="reel-window" data-el="reel" data-has-word="${Boolean(game.word)}">
        <span class="reel-window__word serif" data-el="reel-word">${game.word ?? 'Spin to begin'}</span>
      </div>
      <p class="sr-only" aria-live="polite" data-el="word-status">${game.word ? `Your word: ${game.word}` : ''}</p>
      <button class="btn btn--lux" type="button" data-action="spin">${game.word ? 'Spin again' : 'Spin the deck'}</button>
      <form class="own-word" data-el="own-word">
        <label class="text-sm" for="own-word">Or choose your own word</label>
        <div class="row">
          <input class="input" id="own-word" type="text" maxlength="24" autocomplete="off" enterkeyhint="done"
                 value="${game.wordCustom ? game.word : ''}" placeholder="Your word">
          <button class="btn btn--ghost" type="submit">Use it</button>
        </div>
      </form>
    </section>

    <fieldset class="intentions">
      <legend class="eyebrow eyebrow--muted">Three intentions</legend>
      <p class="text-sm text-muted">One for each part of your life. Rename the headings however you like.</p>
      ${game.intentions.map((it, i) => html`
        <div class="intention">
          <label class="sr-only" for="int-label-${i}">Name for intention ${i + 1}</label>
          <input class="intention__label" id="int-label-${i}" type="text" maxlength="20" data-int-label="${i}"
                 value="${it.label}" autocomplete="off">
          <label class="sr-only" for="int-text-${i}">Your intention for ${it.label}</label>
          <input class="input" id="int-text-${i}" type="text" maxlength="80" data-int-text="${i}"
                 value="${it.text}" placeholder="${INTENTION_DEFAULTS[i]?.placeholder ?? ''}" autocomplete="off">
        </div>`)}
    </fieldset>
    ${roundNav({ next: 'Continue', nextDisabled: !game.word, hint: game.word ? '' : 'Spin or type a word to continue.' })}
  `;
}

export function mount(section, ctx) {
  render(section, template(getGame()));
  const reel = qs('[data-el="reel"]', section);
  const reelWord = qs('[data-el="reel-word"]', section);
  const status = qs('[data-el="word-status"]', section);
  const spinBtn = qs('[data-action="spin"]', section);
  const nextBtn = qs('[data-nav="next"]', section);
  let spinTimer = null;

  function setWord(word, custom) {
    updateGame({ word, wordCustom: custom });
    reelWord.textContent = word;
    reel.dataset.hasWord = 'true';
    status.textContent = `Your word: ${word}`;
    spinBtn.textContent = 'Spin again';
    nextBtn.disabled = false;
    nextBtn.removeAttribute('aria-describedby');
    qs('[data-el="nav-hint"]', section)?.remove();
  }

  function spin() {
    clearTimeout(spinTimer);
    const current = getGame().word;
    const pool = WORDS.filter((w) => w !== current);
    const final = pool[Math.floor(Math.random() * pool.length)];
    qs('#own-word', section).value = '';
    if (reducedMotion()) {
      setWord(final, false);
      return;
    }
    spinBtn.disabled = true;
    reel.dataset.spinning = '';
    let frame = 0;
    const step = () => {
      frame += 1;
      if (frame >= SPIN_FRAMES) {
        delete reel.dataset.spinning;
        spinBtn.disabled = false;
        setWord(final, false);
        reel.classList.remove('is-landed');
        void reel.offsetWidth;
        reel.classList.add('is-landed');
        return;
      }
      reelWord.textContent = pool[Math.floor(Math.random() * pool.length)];
      // Eases out: quick flicks that slow down before landing.
      spinTimer = setTimeout(step, 40 + frame * frame * 1.1);
    };
    step();
  }

  spinBtn.addEventListener('click', spin);

  const offOwn = on(section, 'submit', '[data-el="own-word"]', (e) => {
    e.preventDefault();
    const word = qs('#own-word', section).value.trim().replace(/\s+/g, ' ');
    if (!word) return;
    setWord(word, true);
    ctx.announce(`Your word: ${word}`);
  });

  const saveIntentions = debounced(() => {
    const intentions = getGame().intentions.map((it, i) => ({
      label: qs(`[data-int-label="${i}"]`, section).value,
      text: qs(`[data-int-text="${i}"]`, section).value,
    }));
    updateGame({ intentions });
  });
  ctx.onFlush(() => saveIntentions.flush());
  const offInput = on(section, 'input', '[data-int-label], [data-int-text]', (_, el) => {
    if (el.dataset.intLabel !== undefined) {
      const i = el.dataset.intLabel;
      qs(`label[for="int-text-${i}"]`, section).textContent = `Your intention for ${el.value || 'this part of life'}`;
    }
    saveIntentions();
  });

  return () => {
    clearTimeout(spinTimer);
    saveIntentions.flush();
    offOwn();
    offInput();
  };
}
